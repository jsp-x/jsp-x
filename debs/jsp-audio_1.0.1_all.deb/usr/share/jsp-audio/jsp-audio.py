#!/usr/bin/env python3
# jsp-audio.py - Versión Optimizada en Memoria RAM para Devuan i386
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import font
import os
import shutil
import tempfile
import time
import subprocess
import array
import struct

# Importamos nuestro diccionario de idiomas y componentes GUI/Core
from core.locale import LANGUAGES
from core.audio_engine import AudioEngine
from core.history import HistoryManager
from gui.waveform import WaveformCanvas
from gui.dialogs import SimpleDialog

class ShortcutsDialog(tk.Toplevel):
    """Ventana de diálogo alineada en columnas para los atajos de teclado."""
    def __init__(self, parent, lang_dict):
        super().__init__(parent)
        self.title(lang_dict["shortcuts"])
        self.geometry("480x440")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        main_frame = tk.Frame(self, padx=20, pady=15)
        main_frame.pack(fill=tk.BOTH, expand=True)

        grid_frame = tk.Frame(main_frame)
        grid_frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(grid_frame, text=lang_dict["shortcuts"], font=("Helvetica", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 15))

        shortcuts_list = [
            ("Space", lang_dict["play"]),
            ("Q", lang_dict["stop"]),
            ("Ctrl + O", lang_dict["open"]),
            ("Ctrl + S", lang_dict["save"]),
            ("Ctrl + Z", lang_dict["undo"]),
            ("Ctrl + Y", lang_dict["redo"]),
            ("Ctrl + X", lang_dict["cut"]),
            ("Ctrl + C", lang_dict["copy"]),
            ("Ctrl + V", lang_dict["paste"]),
            ("Supr", lang_dict["delete"]),
            ("Inicio", lang_dict["go_start"]),
            ("Fin", lang_dict.get("go_end_desc", "Go to end"))
        ]

        for idx, (tecla, accion) in enumerate(shortcuts_list):
            row_num = idx + 1
            lbl_tecla = tk.Label(grid_frame, text=tecla, font=("Helvetica", 12, "bold"), fg="#0055ff", anchor=tk.W)
            lbl_tecla.grid(row=row_num, column=0, sticky=tk.W, pady=2, padx=(0, 20))
            
            lbl_accion = tk.Label(grid_frame, text=accion, font=("Helvetica", 12), anchor=tk.W)
            lbl_accion.grid(row=row_num, column=1, sticky=tk.W, pady=2)

        btn_close = tk.Button(grid_frame, text="OK", command=self.destroy, width=12, font=("Helvetica", 12))
        btn_close.grid(row=len(shortcuts_list) + 1, column=0, columnspan=2, pady=(15, 0))


class JSPAudioApp:
    def __init__(self, root):
        self.root = root
        
        # DETECTAR EL IDIOMA DEL SISTEMA OPERATIVO
        self.lang_code = "en"
        try:
            sys_lang = os.environ.get('LANG', '') or os.environ.get('LC_ALL', '')
            if sys_lang:
                sys_lang = sys_lang.lower()
                if "valencia" in sys_lang or sys_lang.startswith("ca"):
                    self.lang_code = "ca"
                else:
                    prefix = sys_lang[:2]
                    if prefix in LANGUAGES:
                        self.lang_code = prefix
        except Exception:
            pass
        
        self.txt = LANGUAGES[self.lang_code]
        self.root.title(self.txt["title"])
        self.root.geometry("1200x768")
        self.root.minsize(980, 600)

        # Cargar icono principal
        try:
            icon_path = os.path.join(os.path.dirname(__file__), "resources", "icon.png")
            if os.path.exists(icon_path):
                img_icon = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, img_icon)
        except Exception:
            pass

        # Cargar iconos PNG desde resources/
        self.icons = {}
        icon_names = ["open", "save", "export", "cut", "copy", "paste", "delete" , "undo", "redo", "exit", "play" , "stop", "forward", "backward"]
        for name in icon_names:
            path = os.path.join(os.path.dirname(__file__), "resources", f"{name}.png")
            if os.path.exists(path):
                try:
                    self.icons[name] = tk.PhotoImage(file=path)
                except Exception:
                    self.icons[name] = None
            else:
                self.icons[name] = None

        # Ocultar ocultos en diálogos
        try:
            try:
                self.root.tk.call('tk_getOpenFile', '-foobarbaz')
            except tk.TclError:
                pass
            self.root.tk.call('set', '::tk::dialog::file::showHiddenBtn', '0')
            self.root.tk.call('set', '::tk::dialog::file::showHiddenVar', '0')
        except Exception:
            pass

        self.audio = AudioEngine()
        self.history = HistoryManager()
        
        # CLIPBOARD Y BUFFER EN MEMORIA
        self.clipboard_samples = None
        self.clipboard_channels = 2
        self.clipboard_sample_rate = 44100

        # Sincronización de reproducción
        self.play_start_time = 0.0
        self.play_start_audio_pos = 0.0
        self.latency_compensation = 0.035

        self.setup_menu()
        self.setup_toolbars()
        self.setup_main_area()
        self.setup_statusbar()
        self.bind_keys()

    # --- AYUDANTES DE EDICIÓN RÁPIDA EN RAM ---
    def _get_sample_indices(self, start_sec, end_sec):
        """Convierte segundos a índices de muestra en el buffer."""
        sr = getattr(self.audio, 'sample_rate', 44100) or 44100
        ch = getattr(self.audio, 'channels', 2) or 2
        start_idx = int(start_sec * sr) * ch
        end_idx = int(end_sec * sr) * ch
        return start_idx, end_idx

    def _flush_mem_to_file_and_render(self):
        """Sincroniza los cambios en la RAM con el archivo temporal para la reproducción y el Canvas."""
        if hasattr(self.audio, 'flush_ram_to_file'):
            self.audio.flush_ram_to_file()
        self.audio._update_metadata()
        self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)

    def update_playback_cursor(self):
        """Mueve el cursor de posición en el canvas."""
        if self.audio.play_process and self.audio.play_process.poll() is None:
            now = time.perf_counter()
            elapsed_real = now - self.play_start_time
            elapsed_compensated = max(0.0, elapsed_real - self.latency_compensation)
            current_audio_time = self.play_start_audio_pos + elapsed_compensated

            if current_audio_time < self.audio.duration:
                width = self.wave_area.winfo_width()
                left_m = getattr(self.wave_area, 'left_margin', 55)
                right_m = getattr(self.wave_area, 'right_margin', 15)
                
                wave_width = width - left_m - right_m
                if wave_width > 0:
                    fraction = current_audio_time / self.audio.duration
                    self.wave_area.cursor_x = left_m + int(fraction * wave_width)
                    self.wave_area.draw_waveform()
                    self.root.after(30, self.update_playback_cursor)
        else:
            self.stop_audio()

    def setup_menu(self):
        menubar = tk.Menu(self.root)
        
        # Archivo
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label=f"  {self.txt['open']} (Ctrl+O)", command=self.open_file, image=self.icons['open'], compound='left')
        file_menu.add_command(label=f"  {self.txt['save']} (Ctrl+S)", command=self.save_file, image=self.icons['save'], compound='left')
        file_menu.add_command(label="  " + self.txt["export"], command=self.export_file, image=self.icons['export'], compound='left')
        file_menu.add_separator()
        file_menu.add_command(label="  " + self.txt["exit"], command=self.on_exit, image=self.icons['exit'], compound='left')
        menubar.add_cascade(label=self.txt["file"], menu=file_menu)

        # Editar
        edit_menu = tk.Menu(menubar, tearoff=0)
        edit_menu.add_command(label=f"  {self.txt['cut']} (Ctrl+X)", command=self.edit_cut, image=self.icons['cut'], compound='left')
        edit_menu.add_command(label=f"  {self.txt['copy']} (Ctrl+C)", command=self.edit_copy, image=self.icons['copy'], compound='left')
        edit_menu.add_command(label=f"  {self.txt['paste']} (Ctrl+V)", command=self.edit_paste, image=self.icons['paste'], compound='left')
        edit_menu.add_command(label=f"  {self.txt['delete']} (Supr)", command=self.edit_delete, image=self.icons['delete'], compound='left')
        edit_menu.add_separator()
        edit_menu.add_command(label=f"  {self.txt['undo']} (Ctrl+Z)", command=self.undo, image=self.icons['undo'], compound='left')
        edit_menu.add_command(label=f"  {self.txt['redo']} (Ctrl+Y)", command=self.redo, image=self.icons['redo'], compound='left')
        menubar.add_cascade(label=self.txt["edit"], menu=edit_menu)

        # Reproducción
        play_menu = tk.Menu(menubar, tearoff=0)
        play_menu.add_command(label=" " + self.txt["go_start"], command=self.go_to_start, image=self.icons['backward'], compound='left')
        play_menu.add_command(label=" " + self.txt["go_end"], command=self.go_to_end, image=self.icons['forward'], compound='left')
        play_menu.add_separator()
        play_menu.add_command(label=f" {self.txt['play']} ({self.txt.get('space_key', 'Space')})", command=self.play_audio, image=self.icons['play'], compound='left')
        play_menu.add_command(label=" " + self.txt["stop"], command=self.stop_audio, image=self.icons['stop'], compound='left')
        menubar.add_cascade(label=self.txt["play_menu"], menu=play_menu)

        # Procesos
        proc_menu = tk.Menu(menubar, tearoff=0)
        proc_menu.add_command(label=self.txt["amplificar"], command=self.proc_amplificar)
        proc_menu.add_command(label=self.txt["normalizar"], command=self.proc_normalizar)
        proc_menu.add_command(label=self.txt["fade_in"], command=self.proc_fade_in)
        proc_menu.add_command(label=self.txt["fade_out"], command=self.proc_fade_out)
        proc_menu.add_separator()
        proc_menu.add_command(label=self.txt["trim"], command=self.proc_trim)
        proc_menu.add_command(label=self.txt["silence"], command=self.proc_insert_silence)
        proc_menu.add_command(label=self.txt["mute"], command=self.edit_mute)
        proc_menu.add_command(label=self.txt["speed"], command=self.proc_speed)
        proc_menu.add_separator()
        proc_menu.add_command(label=self.txt["echo"], command=self.proc_echo)
        proc_menu.add_command(label=self.txt["reverb"], command=self.proc_reverb)
        proc_menu.add_command(label=self.txt["reverse"], command=self.proc_reverse)
        proc_menu.add_command(label=self.txt["pitch"], command=self.proc_pitch)
        menubar.add_cascade(label=self.txt["processes"], menu=proc_menu)

        # Ayuda
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label=self.txt["shortcuts"], command=self.show_shortcuts)
        help_menu.add_command(label=self.txt["about"], command=self.show_about)
        menubar.add_cascade(label=self.txt["help"], menu=help_menu)

        self.root.config(menu=menubar)

    def setup_toolbars(self):
        self.bar_edit = tk.Frame(self.root, bd=1, relief=tk.RAISED)
        self.bar_edit.pack(side=tk.TOP, fill=tk.X)
        
        file_btns = [
            ("open", f"{self.txt['open'].replace('...', '')}", self.open_file, "📂"), 
            ("save", f"{self.txt['save']}", self.save_file, "💾"), 
            ("export", f"{self.txt['export'].replace('...', '')}", self.export_file, "📤")
        ]
        for name, text, cmd, emoji in file_btns:
            btn = tk.Button(self.bar_edit, command=cmd, relief="flat")
            if self.icons.get(name):
                btn.config(image=self.icons[name], text=f" {text}", compound="left")
            else:
                btn.config(text=f"{emoji} {text}")
            btn.pack(side=tk.LEFT, padx=2)
            
        tk.Frame(self.bar_edit, width=10).pack(side=tk.LEFT)
        
        edit_btns = [
            ("cut", f"{self.txt['cut']}", self.edit_cut, "✂"), 
            ("copy", f"{self.txt['copy']}", self.edit_copy, "📋"), 
            ("paste", f"{self.txt['paste']}", self.edit_paste, "📥"), 
            ("delete", f"{self.txt['delete']}", self.edit_delete, "🗑"), 
            ("undo", f"{self.txt['undo']}", self.undo, "↩"), 
            ("redo", f"{self.txt['redo']}", self.redo, "↪")
        ]
        for name, text, cmd, emoji in edit_btns:
            btn = tk.Button(self.bar_edit, command=cmd, relief="flat")
            if self.icons.get(name):
                btn.config(image=self.icons[name], text=f" {text}", compound="left")
            else:
                btn.config(text=f"{emoji} {text}")
            btn.pack(side=tk.LEFT, padx=2)

        self.bar_play = tk.Frame(self.root, bd=1, relief=tk.RAISED)
        self.bar_play.pack(side=tk.TOP, fill=tk.X)
        
        play_btns = [
            (f"▶ {self.txt['play']}", self.play_audio), 
            (f"⏹ {self.txt['stop']}", self.stop_audio), 
            (f"⏮ {self.txt['go_start']}", self.go_to_start), 
            (f"⏭ {self.txt['go_end']}", self.go_to_end)
        ]
        for text, cmd in play_btns:
            tk.Button(self.bar_play, text=text, command=cmd, relief="flat").pack(side=tk.LEFT, padx=5, pady=2)

    def setup_main_area(self):
        self.wave_area = WaveformCanvas(self.root, selection_callback=self.on_selection_change)
        self.wave_area.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    def setup_statusbar(self):
        self.status_frame = tk.Frame(self.root, bd=1, relief=tk.SUNKEN)
        self.status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        self.statusbar = tk.Label(self.status_frame, text=f"{self.txt['status_ready']} | JSP Audio RAM", anchor=tk.W)
        self.statusbar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.info_label = tk.Label(self.status_frame, text=f"{self.txt['selection']}: {self.txt['none']}", anchor=tk.E)
        self.info_label.pack(side=tk.RIGHT, padx=10)

    def on_selection_change(self, start, end, duration):
        if start is not None and end is not None:
            self.info_label.config(text="{} : {:.3f}s | Fin: {:.3f}s | Duración: {:.3f}s".format(self.txt['selection'], start, end, duration))
        else:
            self.info_label.config(text=f"{self.txt['selection']}: {self.txt['none']}")

    # --- LÓGICA DE EDICIÓN ULTRARRÁPIDA EN RAM ---
    def edit_cut(self, event=None):
        start, end, _ = self.wave_area.get_selection_times()
        if start is None: return
        self.history.push_state(self.audio.temp_file)
        
        s_idx, e_idx = self._get_sample_indices(start, end)
        if hasattr(self.audio, 'samples') and self.audio.samples:
            self.clipboard_samples = self.audio.samples[s_idx:e_idx]
            del self.audio.samples[s_idx:e_idx]
            self._flush_mem_to_file_and_render()

    def edit_copy(self, event=None):
        start, end, _ = self.wave_area.get_selection_times()
        if start is None: return
        s_idx, e_idx = self._get_sample_indices(start, end)
        if hasattr(self.audio, 'samples') and self.audio.samples:
            self.clipboard_samples = self.audio.samples[s_idx:e_idx]

    def edit_paste(self, event=None):
        if not self.clipboard_samples: return
        
        width = self.wave_area.winfo_width()
        left_m = getattr(self.wave_area, 'left_margin', 55)
        right_m = getattr(self.wave_area, 'right_margin', 15)
        wave_width = width - left_m - right_m
        relative_cursor_x = max(0, self.wave_area.cursor_x - left_m)
        pos_sec = (relative_cursor_x / wave_width) * self.audio.duration if wave_width > 0 else 0.0

        self.history.push_state(self.audio.temp_file)
        p_idx, _ = self._get_sample_indices(pos_sec, pos_sec)
        
        if hasattr(self.audio, 'samples'):
            self.audio.samples[p_idx:p_idx] = self.clipboard_samples
            self._flush_mem_to_file_and_render()

    def edit_delete(self, event=None):
        start, end, _ = self.wave_area.get_selection_times()
        if start is None: return
        self.history.push_state(self.audio.temp_file)
        
        s_idx, e_idx = self._get_sample_indices(start, end)
        if hasattr(self.audio, 'samples') and self.audio.samples:
            del self.audio.samples[s_idx:e_idx]
            self._flush_mem_to_file_and_render()

    def edit_mute(self):
        start, end, dur = self.wave_area.get_selection_times()
        if start is None or dur <= 0: return
        self.history.push_state(self.audio.temp_file)
        
        s_idx, e_idx = self._get_sample_indices(start, end)
        if hasattr(self.audio, 'samples') and self.audio.samples:
            for i in range(s_idx, min(e_idx, len(self.audio.samples))):
                self.audio.samples[i] = 0
            self._flush_mem_to_file_and_render()
            self.statusbar.config(text="Mute OK (RAM).")

    # --- REPRODUCCIÓN Y OTROS CONTROLES ---
    def play_audio(self, event=None):
        if not self.audio.temp_file: return
        self.audio.stop()
        
        start_t = 0.0
        if self.wave_area.selection_start_x is not None:
             start_t, _, _ = self.wave_area.get_selection_times()
        
        self.play_start_audio_pos = start_t
        self.play_start_time = time.perf_counter()
        self.audio.play(start_time=start_t)
        self.update_playback_cursor()

    def stop_audio(self, event=None):
        self.audio.stop()
        self.wave_area.cursor_x = getattr(self.wave_area, 'left_margin', 55)
        self.wave_area.draw_waveform()

    def go_to_start(self, event=None):
        self.stop_audio()
        self.wave_area.cursor_x = getattr(self.wave_area, 'left_margin', 55)
        self.wave_area.selection_start_x = None
        self.wave_area.selection_end_x = None
        self.wave_area.draw_waveform()
        self.on_selection_change(None, None, 0.0)

    def go_to_end(self, event=None):
        self.stop_audio()
        width = self.wave_area.winfo_width()
        right_m = getattr(self.wave_area, 'right_margin', 15)
        self.wave_area.cursor_x = width - right_m
        self.wave_area.selection_start_x = None
        self.wave_area.selection_end_x = None
        self.wave_area.draw_waveform()
        self.on_selection_change(None, None, 0.0)

    # --- PROCESOS CON SOX COMO FALLBACK PARA EFECTOS ---
    def apply_effect_to_selection_or_all(self, effect_args):
        if not self.audio.temp_file: return
        self.history.push_state(self.audio.temp_file)
        start, end, duration = self.wave_area.get_selection_times()
        
        if start is None or end is None or duration <= 0.05:
            if self.audio.apply_sox_effect(effect_args):
                self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)
                return True
            return False

        temp_dir = tempfile.gettempdir()
        p1, p2, p3, p2_effect, out = [os.path.join(temp_dir, f"jsp_eff_{x}.wav") for x in ["p1", "p2", "p3", "p2_mod", "out"]]
        try:
            subprocess.run(['sox', self.audio.temp_file, p1, 'trim', '0', "{:.3f}".format(start)], check=True)
            subprocess.run(['sox', self.audio.temp_file, p2, 'trim', "{:.3f}".format(start), "={:.3f}".format(end)], check=True)
            subprocess.run(['sox', self.audio.temp_file, p3, 'trim', "{:.3f}".format(end)], check=True)

            subprocess.run(['sox', p2, p2_effect] + effect_args, check=True)
            subprocess.run(['sox', p1, p2_effect, p3, out], check=True)

            os.replace(out, self.audio.temp_file)
            for f in [p1, p2, p3, p2_effect]:
                if os.path.exists(f): os.remove(f)

            self.audio._update_metadata()
            self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)
            return True
        except Exception as e:
            messagebox.showerror("Error", "No se pudo aplicar el efecto.")
            return False

    def proc_amplificar(self):
        if not self.audio.temp_file: return
        d = SimpleDialog(self.root, self.txt["amplificar"], "dB (ej: 3.5 / -3.5):", "3.0")
        self.root.wait_window(d)
        if d.result:
            try:
                val = float(d.result)
                if self.apply_effect_to_selection_or_all(['gain', "{:.1f}".format(val)]):
                    self.statusbar.config(text="Volumen: {:+.1f} dB".format(val))
            except ValueError:
                messagebox.showerror("Error", "Format incorrecte.")

    def proc_normalizar(self):
        if not self.audio.temp_file: return
        if self.apply_effect_to_selection_or_all(['gain', '-n', '-1']):
            self.statusbar.config(text="Normalitzat a -1dB.")

    def proc_fade_in(self):
        if not self.audio.temp_file: return
        _, _, dur = self.wave_area.get_selection_times()
        if dur == 0: dur = 2.0
        if self.apply_effect_to_selection_or_all(['fade', 't', "{:.3f}".format(dur)]):
            self.statusbar.config(text="Fade In OK.")

    def proc_fade_out(self):
        if not self.audio.temp_file: return
        _, _, dur = self.wave_area.get_selection_times()
        if dur == 0: dur = 2.0
        if self.apply_effect_to_selection_or_all(['fade', 't', '0', '0', "{:.3f}".format(dur)]):
            self.statusbar.config(text="Fade Out OK.")

    def proc_trim(self):
        start, end, _ = self.wave_area.get_selection_times()
        if start is None or end is None or start == end: return
        self.history.push_state(self.audio.temp_file)
        if self.audio.apply_sox_effect(['trim', "{:.3f}".format(start), "={:.3f}".format(end)]):
            self.audio._update_metadata()
            self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)
            self.statusbar.config(text="Audio trim.")

    def proc_insert_silence(self):
        if not self.audio.temp_file: return
        d = SimpleDialog(self.root, self.txt["silence"], "Sec:", "2.0")
        self.root.wait_window(d)
        if d.result:
            try:
                dur = float(d.result)
                sr = getattr(self.audio, 'sample_rate', 44100) or 44100
                ch = getattr(self.audio, 'channels', 2) or 2
                num_samples = int(dur * sr) * ch
                silence_arr = array.array('h', [0] * num_samples)

                width = self.wave_area.winfo_width()
                left_m = getattr(self.wave_area, 'left_margin', 55)
                right_m = getattr(self.wave_area, 'right_margin', 15)
                wave_width = width - left_m - right_m
                relative_cursor_x = max(0, self.wave_area.cursor_x - left_m)
                pos = (relative_cursor_x / wave_width) * self.audio.duration if wave_width > 0 else 0.0

                self.history.push_state(self.audio.temp_file)
                p_idx, _ = self._get_sample_indices(pos, pos)
                
                if hasattr(self.audio, 'samples'):
                    self.audio.samples[p_idx:p_idx] = silence_arr
                    self._flush_mem_to_file_and_render()
                    self.statusbar.config(text="Silenci insertat.")
            except ValueError:
                messagebox.showerror("Error", "Valor incorrecte.")

    def proc_speed(self):
        if not self.audio.temp_file: return
        d = SimpleDialog(self.root, self.txt["speed"], "X (ej: 1.5 o 0.8):", "1.2")
        self.root.wait_window(d)
        if d.result:
            try:
                val = float(d.result)
                if self.apply_effect_to_selection_or_all(['speed', "{:.2f}".format(val)]):
                    self.audio._update_metadata()
                    self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)
                    self.statusbar.config(text="Velocitat: {}x".format(val))
            except ValueError:
                messagebox.showerror("Error", "Valor incorrecte.")

    def proc_echo(self):
        if not self.audio.temp_file: return
        d = SimpleDialog(self.root, self.txt["echo"], "retraso_ms decaimiento:", "250 0.4")
        self.root.wait_window(d)
        if d.result:
            try:
                delay_ms, decay = d.result.split()
                delay_sec = float(delay_ms) / 1000.0
                decay_val = float(decay)
                if self.apply_effect_to_selection_or_all(['echo', '0.8', '0.8', "{:.3f}".format(delay_sec), "{:.2f}".format(decay_val)]):
                    self.statusbar.config(text="Eco OK.")
            except Exception:
                messagebox.showerror("Error", "Valor incorrecte.")

    def proc_reverb(self):
        if not self.audio.temp_file: return
        d = SimpleDialog(self.root, self.txt["reverb"], "Reverb (0-100):", "50")
        self.root.wait_window(d)
        if d.result:
            try:
                val = int(d.result)
                if self.apply_effect_to_selection_or_all(['reverb', str(val)]):
                    self.statusbar.config(text="Reverb OK.")
            except ValueError:
                messagebox.showerror("Error", "Valor incorrecte.")

    def proc_reverse(self):
        if not self.audio.temp_file: return
        if self.apply_effect_to_selection_or_all(['reverse']):
            self.statusbar.config(text="Invertit OK.")

    def proc_pitch(self):
        if not self.audio.temp_file: return
        d = SimpleDialog(self.root, self.txt["pitch"], "Semitons (ej: -3 o +3):", "2")
        self.root.wait_window(d)
        if d.result:
            try:
                semitones = float(d.result)
                cents = int(semitones * 100)
                if self.apply_effect_to_selection_or_all(['pitch', str(cents)]):
                    self.statusbar.config(text="Semitons: {:+.1f}".format(semitones))
            except ValueError:
                messagebox.showerror("Error", "Valor incorrecte.")

    # --- ARCHIVOS ---
    def open_file(self, event=None): 
        home_dir = os.path.expanduser("~")
        f = filedialog.askopenfilename(
            title=self.txt["open"],
            initialdir=home_dir,
            filetypes=[
                ("Audio", "*.wav *.mp3 *.ogg *.flac *.aiff"),
                ("WAV (*.wav)", "*.wav"),
                ("MP3 (*.mp3)", "*.mp3"),
                ("Ogg (*.ogg)", "*.ogg"),
                ("FLAC (*.flac)", "*.flac"),
                ("AIFF (*.aiff)", "*.aiff"),
                ("All", "*.*")
            ]
        )
        if f and self.audio.load_file(f): 
            self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)
            self.statusbar.config(text="Loaded: {}".format(os.path.basename(f)))

    def save_file(self, event=None):
        if not self.audio.temp_file: return
        home_dir = os.path.expanduser("~")
        save_path = filedialog.asksaveasfilename(
            title=self.txt["save"],
            initialdir=home_dir,
            defaultextension=".wav",
            filetypes=[("WAV (*.wav)", "*.wav")]
        )
        if save_path:
            shutil.copy2(self.audio.temp_file, save_path)
            self.statusbar.config(text="Saved: {}".format(os.path.basename(save_path)))

    def export_file(self, event=None):
        if not self.audio.temp_file: return
        home_dir = os.path.expanduser("~")
        export_path = filedialog.asksaveasfilename(
            title=self.txt["export"],
            initialdir=home_dir,
            filetypes=[
                ("MP3 (*.mp3)", "*.mp3"),
                ("Ogg (*.ogg)", "*.ogg"),
                ("FLAC (*.flac)", "*.flac"),
                ("WAV (*.wav)", "*.wav")
            ]
        )
        if export_path:
            name, ext = os.path.splitext(export_path)
            ext = ext.lower()
            if not ext:
                export_path = export_path + ".mp3"
                ext = ".mp3"
            
            format_ext = ext.replace(".", "")
            self.statusbar.config(text="Export: {}...".format(format_ext.upper()))
            self.root.update()
            
            if self.audio.export(export_path, format_ext):
                self.statusbar.config(text="Exported: {}".format(os.path.basename(export_path)))
            else:
                messagebox.showerror("Error", "Export fail.")

    def bind_keys(self):
        self.root.bind("<space>", self.play_audio)
        self.root.bind("<q>", self.stop_audio)
        self.root.bind("<Control-o>", self.open_file)
        self.root.bind("<Control-s>", self.save_file)
        self.root.bind("<Control-z>", lambda e: self.undo())
        self.root.bind("<Control-y>", lambda e: self.redo())
        self.root.bind("<Control-x>", self.edit_cut)
        self.root.bind("<Control-c>", self.edit_copy)
        self.root.bind("<Control-v>", self.edit_paste)
        self.root.bind("<Delete>", self.edit_delete)
        self.root.bind("<Home>", self.go_to_start)
        self.root.bind("<End>", self.go_to_end)

    def show_shortcuts(self):
        ShortcutsDialog(self.root, self.txt)

    def show_about(self):
        messagebox.showinfo(
            "JSP Audio",
            "JSP Audio v1.1 (RAM Engine)\n\n"
            "An optimized audio editor for i386 Devuan.\n"
            "Python3 + In-Memory Arrays + SoX"
        )

    def undo(self): 
        if self.history.undo(self.audio):
            self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)
            self.statusbar.config(text="Undo.")

    def redo(self): 
        if self.history.redo(self.audio):
            self.wave_area.set_audio(self.audio.temp_file, self.audio.duration)
            self.statusbar.config(text="Redo.")

    def on_exit(self): 
        self.audio.cleanup()
        self.history.cleanup()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    
    tamanio_letra = 12
    font.nametofont("TkDefaultFont").configure(size=tamanio_letra)
    font.nametofont("TkMenuFont").configure(size=tamanio_letra)
    
    app = JSPAudioApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_exit)
    root.mainloop()
