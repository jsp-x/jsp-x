# core/history.py - Versión Híbrida (Disco + Sincronización de RAM)
import os
import shutil
import tempfile

class HistoryManager:
    def __init__(self, max_steps=10):
        self.max_steps = max_steps
        self.undo_stack = []
        self.redo_stack = []

    def push_state(self, current_file):
        """Guarda una copia de respaldo del estado actual en disco antes de modificarlo."""
        if not current_file or not os.path.exists(current_file):
            return
        
        # Limitar el tamaño de la pila eliminando la copia más antigua
        if len(self.undo_stack) >= self.max_steps:
            oldest = self.undo_stack.pop(0)
            if os.path.exists(oldest):
                os.remove(oldest)

        # Crear respaldo en /tmp
        temp_fd, backup_path = tempfile.mkstemp(suffix=".wav", prefix="jsp_hist_")
        os.close(temp_fd)
        shutil.copy2(current_file, backup_path)
        
        self.undo_stack.append(backup_path)
        self.clear_redo()

    def undo(self, audio_engine):
        """Restaura el estado anterior, recupera el WAV y resincroniza el buffer de RAM."""
        if not self.undo_stack or not audio_engine.temp_file:
            return False

        current_file = audio_engine.temp_file

        # Guardar el estado actual en la pila de Redo antes de volver atrás
        temp_fd, backup_path = tempfile.mkstemp(suffix=".wav", prefix="jsp_hist_")
        os.close(temp_fd)
        shutil.copy2(current_file, backup_path)
        self.redo_stack.append(backup_path)

        # Restaurar el estado previo de Undo sobre el archivo de trabajo
        previous_state = self.undo_stack.pop()
        shutil.copy2(previous_state, current_file)
        os.remove(previous_state)

        # Sincronización crítica: Recargar el buffer PCM de RAM y refrescar metadatos
        audio_engine.sync_file_to_ram()
        audio_engine._update_metadata()
        return True

    def redo(self, audio_engine):
        """Reaplica la acción deshecha y resincroniza el buffer de RAM."""
        if not self.redo_stack or not audio_engine.temp_file:
            return False

        current_file = audio_engine.temp_file

        # Guardar el estado actual de vuelta a Undo
        temp_fd, backup_path = tempfile.mkstemp(suffix=".wav", prefix="jsp_hist_")
        os.close(temp_fd)
        shutil.copy2(current_file, backup_path)
        self.undo_stack.append(backup_path)

        # Restaurar el estado de Redo
        next_state = self.redo_stack.pop()
        shutil.copy2(next_state, current_file)
        os.remove(next_state)

        # Sincronización crítica: Recargar el buffer PCM de RAM y refrescar metadatos
        audio_engine.sync_file_to_ram()
        audio_engine._update_metadata()
        return True

    def clear_redo(self):
        """Limpia los archivos temporales de la pila de Redo."""
        while self.redo_stack:
            path = self.redo_stack.pop()
            if os.path.exists(path):
                os.remove(path)

    def cleanup(self):
        """Elimina todos los archivos temporales del historial al cerrar el programa."""
        self.clear_redo()
        while self.undo_stack:
            path = self.undo_stack.pop()
            if os.path.exists(path):
                os.remove(path)# core/history.py - Versión Híbrida (Disco + Sincronización de RAM)
import os
import shutil
import tempfile

class HistoryManager:
    def __init__(self, max_steps=10):
        self.max_steps = max_steps
        self.undo_stack = []
        self.redo_stack = []

    def push_state(self, current_file):
        """Guarda una copia de respaldo del estado actual en disco antes de modificarlo."""
        if not current_file or not os.path.exists(current_file):
            return
        
        # Limitar el tamaño de la pila eliminando la copia más antigua
        if len(self.undo_stack) >= self.max_steps:
            oldest = self.undo_stack.pop(0)
            if os.path.exists(oldest):
                os.remove(oldest)

        # Crear respaldo en /tmp
        temp_fd, backup_path = tempfile.mkstemp(suffix=".wav", prefix="jsp_hist_")
        os.close(temp_fd)
        shutil.copy2(current_file, backup_path)
        
        self.undo_stack.append(backup_path)
        self.clear_redo()

    def undo(self, audio_engine):
        """Restaura el estado anterior, recupera el WAV y resincroniza el buffer de RAM."""
        if not self.undo_stack or not audio_engine.temp_file:
            return False

        current_file = audio_engine.temp_file

        # Guardar el estado actual en la pila de Redo antes de volver atrás
        temp_fd, backup_path = tempfile.mkstemp(suffix=".wav", prefix="jsp_hist_")
        os.close(temp_fd)
        shutil.copy2(current_file, backup_path)
        self.redo_stack.append(backup_path)

        # Restaurar el estado previo de Undo sobre el archivo de trabajo
        previous_state = self.undo_stack.pop()
        shutil.copy2(previous_state, current_file)
        os.remove(previous_state)

        # Sincronización crítica: Recargar el buffer PCM de RAM y refrescar metadatos
        audio_engine.sync_file_to_ram()
        audio_engine._update_metadata()
        return True

    def redo(self, audio_engine):
        """Reaplica la acción deshecha y resincroniza el buffer de RAM."""
        if not self.redo_stack or not audio_engine.temp_file:
            return False

        current_file = audio_engine.temp_file

        # Guardar el estado actual de vuelta a Undo
        temp_fd, backup_path = tempfile.mkstemp(suffix=".wav", prefix="jsp_hist_")
        os.close(temp_fd)
        shutil.copy2(current_file, backup_path)
        self.undo_stack.append(backup_path)

        # Restaurar el estado de Redo
        next_state = self.redo_stack.pop()
        shutil.copy2(next_state, current_file)
        os.remove(next_state)

        # Sincronización crítica: Recargar el buffer PCM de RAM y refrescar metadatos
        audio_engine.sync_file_to_ram()
        audio_engine._update_metadata()
        return True

    def clear_redo(self):
        """Limpia los archivos temporales de la pila de Redo."""
        while self.redo_stack:
            path = self.redo_stack.pop()
            if os.path.exists(path):
                os.remove(path)

    def cleanup(self):
        """Elimina todos los archivos temporales del historial al cerrar el programa."""
        self.clear_redo()
        while self.undo_stack:
            path = self.undo_stack.pop()
            if os.path.exists(path):
                os.remove(path)
