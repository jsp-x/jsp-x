# core/audio_engine.py
import os
import subprocess
import tempfile
import wave
import array

class AudioEngine:
    def __init__(self):
        self.temp_file = None
        self.sample_rate = 44100
        self.channels = 2
        self.duration = 0.0
        self.play_process = None
        self.samples = array.array('h')  # Buffer PCM de 16 bits en memoria RAM

    def load_file(self, filepath):
        """Convierte cualquier formato soportado a un WAV temporal de trabajo y lo carga en RAM."""
        self.cleanup()
        
        # Crear un archivo temporal único
        temp_fd, self.temp_file = tempfile.mkstemp(suffix=".wav", prefix="jsp_audio_")
        os.close(temp_fd)

        # Convertir a WAV estándar (16-bit PCM, 44100Hz, estéreo por defecto)
        cmd = [
            'ffmpeg', '-y', '-i', filepath,
            '-acodec', 'pcm_s16le', '-ar', str(self.sample_rate),
            self.temp_file
        ]
        
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            self._update_metadata()
            self.sync_file_to_ram()  # Cargamos el archivo en el buffer de RAM
            return True
        except subprocess.CalledProcessError:
            self.cleanup()
            return False

    def _update_metadata(self):
        """Lee las propiedades básicas del WAV temporal."""
        if not self.temp_file or not os.path.exists(self.temp_file):
            return
        with wave.open(self.temp_file, 'rb') as w:
            self.channels = w.getnchannels()
            self.sample_rate = w.getframerate()
            frames = w.getnframes()
            self.duration = frames / float(self.sample_rate)

    def sync_file_to_ram(self):
        """Lee las muestras del archivo WAV temporal y las vuelca en la lista/array de RAM."""
        if not self.temp_file or not os.path.exists(self.temp_file):
            self.samples = array.array('h')
            return
        try:
            with wave.open(self.temp_file, 'rb') as w:
                frames = w.readframes(w.getnframes())
                self.samples = array.array('h', frames)
        except Exception:
            self.samples = array.array('h')

    def flush_ram_to_file(self):
        """Vuelca el buffer de RAM al archivo WAV disco de forma ultra-rápida."""
        if not self.temp_file or not hasattr(self, 'samples'):
            return
        try:
            with wave.open(self.temp_file, 'wb') as w:
                w.setnchannels(self.channels)
                w.setsampwidth(2)  # 16-bit PCM (2 bytes)
                w.setframerate(self.sample_rate)
                w.writeframes(self.samples.tobytes())
            self._update_metadata()
        except Exception as e:
            print(f"Error escribiendo RAM a disco: {e}")

    def play(self, start_time=0.0, play_duration=None):
        """Reproduce el audio temporal usando play de SoX (permite trim preciso) o aplay como fallback."""
        if not self.temp_file:
            return
        self.stop()
        
        # Si queremos un tramo específico de tiempo (reproducir selección)
        if start_time > 0.0 or play_duration is not None:
            if play_duration is not None:
                cmd = ['play', '-q', self.temp_file, 'trim', f"{start_time:.3f}", f"{play_duration:.3f}"]
            else:
                cmd = ['play', '-q', self.temp_file, 'trim', f"{start_time:.3f}"]
            
            try:
                self.play_process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
            except FileNotFoundError:
                pass # Si no encuentra 'play' de SoX, usará el fallback de abajo
        
        # Fallback estándar con aplay o sox play
        try:
            cmd = ['play', '-q', self.temp_file]
            self.play_process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except FileNotFoundError:
            cmd = ['aplay', '-q', self.temp_file]
            self.play_process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def stop(self):
        """Detiene la reproducción activa."""
        if self.play_process:
            try:
                self.play_process.terminate()
            except Exception:
                pass
            self.play_process = None

    def apply_sox_effect(self, effect_args):
        """Aplica un efecto SoX directamente sobre el archivo y resincroniza la RAM."""
        if not self.temp_file:
            return
        
        temp_fd, out_file = tempfile.mkstemp(suffix=".wav", prefix="jsp_effect_")
        os.close(temp_fd)

        cmd = ['sox', self.temp_file, out_file] + effect_args
        try:
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            os.replace(out_file, self.temp_file)
            self._update_metadata()
            self.sync_file_to_ram()  # Actualizamos el buffer tras procesar con SoX
            return True
        except subprocess.CalledProcessError:
            if os.path.exists(out_file):
                os.remove(out_file)
            return False

    def export(self, output_path, format_ext):
        """Exporta el WAV temporal al formato final deseado."""
        if not self.temp_file:
            return False
        # Nos aseguramos de exportar el estado actual en RAM
        self.flush_ram_to_file()
        
        cmd = ['ffmpeg', '-y', '-i', self.temp_file, output_path]
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            return True
        except subprocess.CalledProcessError:
            return False

    def cleanup(self):
        """Elimina los archivos temporales y vacía el buffer al cerrar el programa."""
        self.stop()
        self.samples = array.array('h')
        if self.temp_file and os.path.exists(self.temp_file):
            try:
                os.remove(self.temp_file)
            except OSError:
                pass
            self.temp_file = None
