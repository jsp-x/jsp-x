# gui/waveform.py
import tkinter as tk
import os

class WaveformCanvas(tk.Canvas):
    def __init__(self, parent, selection_callback=None, **kwargs):
        # 1. FONDO DE ONDA EN #121212 (MODO OSCURO)
        super().__init__(parent, bg="#121212", highlightthickness=0, **kwargs)
        self.selection_callback = selection_callback

        # Márgenes para las reglas (Volumen a la izquierda, tiempo abajo)
        self.left_margin = 55
        self.right_margin = 15
        self.top_margin = 15
        self.bottom_margin = 30

        # Datos del archivo / RAM
        self.audio_path = None
        self.duration = 0.0
        self.audio_data = []

        # Estado visual
        self.cursor_x = self.left_margin
        self.selection_start_x = None
        self.selection_end_x = None
        
        # Colores optimizados para el contraste en fondo #121212
        self.wave_color = "#0088ff"      # Azul brillante muy nítido
        self.select_color = "#1a3a5f"    # Azul marino traslúcido elegante
        self.cursor_color = "#ff3333"    # Rojo brillante de alta visibilidad

        # Eventos del ratón para selección y cursor
        self.bind("<ButtonPress-1>", self.on_click)
        self.bind("<B1-Motion>", self.on_drag)
        self.bind("<Configure>", self.on_resize)

    def set_audio(self, audio_engine_or_path, duration=0.0):
        """Genera los picos visuales de forma ultrarrápida extrayendo datos directamente de RAM o del motor."""
        self.audio_data = []
        
        # Caso 1: Le pasamos directamente el objeto AudioEngine (Lectura en RAM instantánea)
        if hasattr(audio_engine_or_path, 'samples'):
            self.duration = getattr(audio_engine_or_path, 'duration', duration)
            samples = audio_engine_or_path.samples
            n_samples = len(samples)
            
            if n_samples > 0:
                max_display_points = 2000
                step = max(1, n_samples // max_display_points)
                # Normalizamos muestras de 16-bit PCM (-32768 a 32767) a rango -1.0 a 1.0
                self.audio_data = [samples[i] / 32768.0 for i in range(0, n_samples, step)]
        
        # Caso 2: Si por algún motivo recibe solo la ruta de archivo (Fallback de seguridad)
        elif isinstance(audio_engine_or_path, str) and os.path.exists(audio_engine_or_path):
            self.audio_path = audio_engine_or_path
            self.duration = duration
            import wave, struct
            try:
                with wave.open(audio_engine_or_path, 'rb') as wf:
                    n_frames = wf.getnframes()
                    frames = wf.readframes(n_frames)
                    # Lectura completa en bloque
                    raw_samples = struct.unpack(f"<{n_frames * wf.getnchannels()}h", frames)
                    step = max(1, len(raw_samples) // 2000)
                    self.audio_data = [raw_samples[i] / 32768.0 for i in range(0, len(raw_samples), step)]
            except Exception as e:
                print(f"Error decodificando onda: {e}")
                self.audio_data = []

        # Reiniciamos selección
        self.selection_start_x = None
        self.selection_end_x = None
        self.cursor_x = self.left_margin
        self.draw_waveform()
        if self.selection_callback:
            self.selection_callback(None, None, 0.0)

    def get_selection_times(self):
        """Calcula de forma milimétrica los tiempos en base a los píxeles seleccionados."""
        if self.duration <= 0:
            return None, None, 0.0
        width = self.winfo_width()
        wave_width = width - self.left_margin - self.right_margin
        if wave_width <= 0 or self.selection_start_x is None or self.selection_end_x is None:
            return None, None, 0.0

        x1 = min(self.selection_start_x, self.selection_end_x)
        x2 = max(self.selection_start_x, self.selection_end_x)

        # Ajuste de bordes al área útil de la onda
        x1_rel = max(0, x1 - self.left_margin)
        x2_rel = max(0, x2 - self.left_margin)

        t1 = (x1_rel / wave_width) * self.duration
        t2 = (x2_rel / wave_width) * self.duration
        return round(t1, 3), round(t2, 3), round(t2 - t1, 3)

    def draw_waveform(self):
        """Renderiza todo el entorno visual de la onda, escalas y selectores."""
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width < 100 or height < 50:
            return

        wave_width = width - self.left_margin - self.right_margin
        wave_height = height - self.top_margin - self.bottom_margin
        mid_y = self.top_margin + wave_height // 2

        # 1. Dibujamos caja de selección traslúcida
        if self.selection_start_x is not None and self.selection_end_x is not None:
            x1 = max(self.left_margin, min(self.selection_start_x, self.selection_end_x))
            x2 = min(width - self.right_margin, max(self.selection_start_x, self.selection_end_x))
            self.create_rectangle(x1, self.top_margin, x2, self.top_margin + wave_height, fill=self.select_color, outline="")

        # 2. Línea central de silencio absoluto
        self.create_line(self.left_margin, mid_y, width - self.right_margin, mid_y, fill="#444444")

        # 3. Dibujamos la onda de sonido
        if self.audio_data and wave_width > 0:
            n_points = len(self.audio_data)
            
            for x in range(wave_width):
                canvas_x = self.left_margin + x
                idx = int((x / wave_width) * n_points)
                val = self.audio_data[min(idx, n_points - 1)]
                
                # Amplitud vertical de dibujo
                amp_y = int(val * (wave_height // 2) * 0.95)
                self.create_line(canvas_x, mid_y - amp_y, canvas_x, mid_y + amp_y, fill=self.wave_color)

        # 4. Dibujar el cursor de reproducción rojo
        if self.cursor_x is not None:
            cx = max(self.left_margin, min(self.cursor_x, width - self.right_margin))
            self.create_line(cx, self.top_margin - 5, cx, self.top_margin + wave_height + 5, fill=self.cursor_color, width=2)

        # 5. Dibujar escalas estáticas externas (Volumen y Regla de segundos)
        self._draw_scales_and_labels(width, height, wave_width, wave_height, mid_y)

    def _draw_scales_and_labels(self, width, height, wave_width, wave_height, mid_y):
        # Marco exterior del gráfico
        self.create_rectangle(self.left_margin, self.top_margin, width - self.right_margin, self.top_margin + wave_height, outline="#444444")

        # Regla de volumen izquierda (dB)
        ticks_vol = [("+1.0", self.top_margin), (" 0.0", mid_y), ("-1.0", self.top_margin + wave_height)]
        for label, y in ticks_vol:
            self.create_line(self.left_margin - 5, y, self.left_margin, y, fill="#888888")
            self.create_text(self.left_margin - 8, y, text=label, anchor=tk.E, font=("Helvetica", 10), fill="#888888")

        # Regla de tiempo inferior (segundos)
        if self.duration > 0 and wave_width > 0:
            divs = 10
            for i in range(divs + 1):
                fraction = i / divs
                sec = fraction * self.duration
                x = self.left_margin + int(fraction * wave_width)
                
                # Marcas y textos
                self.create_line(x, self.top_margin + wave_height, x, self.top_margin + wave_height + 5, fill="#888888")
                self.create_text(x, self.top_margin + wave_height + 8, text="{:.2f}s".format(sec), anchor=tk.N, font=("Helvetica", 10), fill="#888888")

    def on_click(self, event):
        width = self.winfo_width()
        if event.x < self.left_margin or event.x > width - self.right_margin:
            return

        self.cursor_x = event.x
        self.selection_start_x = event.x
        self.selection_end_x = event.x
        self.draw_waveform()
        if self.selection_callback:
            self.selection_callback(None, None, 0.0)

    def on_drag(self, event):
        width = self.winfo_width()
        self.selection_end_x = max(self.left_margin, min(event.x, width - self.right_margin))
        self.cursor_x = self.selection_end_x
        self.draw_waveform()

        if self.selection_callback:
            t1, t2, dur = self.get_selection_times()
            self.selection_callback(t1, t2, dur)

    def on_resize(self, event):
        self.draw_waveform()
