# gui/dialogs.py
import tkinter as tk

class SimpleDialog(tk.Toplevel):
    def __init__(self, parent, title, label_text, default_val="", txt_ok="OK", txt_cancel="Cancel"):
        super().__init__(parent)
        self.title(title)
        self.geometry("300x140")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.result = None

        # Centrado dinámico sobre la ventana padre
        self.update_idletasks()
        px = parent.winfo_x() + (parent.winfo_width() // 2) - (300 // 2)
        py = parent.winfo_y() + (parent.winfo_height() // 2) - (140 // 2)
        self.geometry(f"+{max(0, px)}+{max(0, py)}")

        # Contenido
        tk.Label(self, text=label_text, font=("Helvetica", 11)).pack(pady=(12, 4))
        
        self.entry = tk.Entry(self, font=("Helvetica", 11), justify="center")
        self.entry.insert(0, default_val)
        self.entry.pack(pady=4, padx=15, fill=tk.X)
        self.entry.focus_set()
        self.entry.select_range(0, tk.END)  # Selecciona el texto por defecto para sobreescribir rápido

        # Botones
        btn_frame = tk.Frame(self)
        btn_frame.pack(pady=(10, 0))
        
        tk.Button(btn_frame, text=txt_ok, command=self.on_ok, width=10).pack(side=tk.LEFT, padx=6)
        tk.Button(btn_frame, text=txt_cancel, command=self.destroy, width=10).pack(side=tk.LEFT, padx=6)

        # Eventos de teclado (Enter para aceptar, Escape para cancelar)
        self.bind("<Return>", lambda e: self.on_ok())
        self.bind("<Escape>", lambda e: self.destroy())

    def on_ok(self):
        self.result = self.entry.get()
        self.destroy()
