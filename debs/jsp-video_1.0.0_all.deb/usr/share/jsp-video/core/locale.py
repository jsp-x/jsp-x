# core/locale.py

VIDEO_LANGUAGES = {
    "en": {
        "title": "JSP Video - Video Clipper i386",
        "file": "File", "open": "Open Video...", "save": "Save As...", "export": "Export Video...", "exit": "Exit",
        "edit": "Edit", "undo": "Undo", "redo": "Redo", "cut": "Cut fragment", "copy": "Copy fragment", "paste": "Paste fragment", "set_start": "Set Start [A]", "set_end": "Set End [B]", "clear_sel": "Clear selection", "delete": "Delete fragment",
        "play": "Play", "pause": "Pause", "stop": "Stop", "go_start": "Go to Start", "go_end": "Go to End", "undo-1": "Step backward -1s", "redo+1": "Step forward +1s",
        "tools": "Tools", "join": "Append video...", "rotate": "Rotate +90°", "unrotate": "Rotate -90°", "extract_audio": "Extract Audio", "capture": "Frame capture",
        "help": "Help", "shortcuts": "Keyboard Shortcuts", "about": "About", "status_ready": "Ready", "selection": "Selection", "none": "None",
        "space_key": "Space", "left_arrow": "Left arrow", "right_arrow": "Right arrow", 
        "main_area_open": "Open a file to begin editing", "duration": "Duration", "error_play": "The player could not be started.", "export_video": "Video exported", 
        "undo_end": "Undo completed.", "redo_end": "Redo completed.", "undo_no": "There are no more actions to undo.", "redo_no": "There are no more actions to be taken.", "frag_copy": "Fragment copied to the clipboard.", 
        "attention": "Attention", "no_clip": "The clipboard is empty.", "no_paste": "It couldn't be attached.", "mark": "Mark part [A-B] first.", "error_delete": "Error deleting.", "save_photo": "Save frame.",
        "success": "Success", "join_success": "Video successfully added to the end of the footage.", "editing": "EDITING", "start_video": "Start video", "stop_video": "Stop video.", 
        "no_meta": "Error reading metadata.", "video": "Video", "video_success": "Video saved successfully!", "select_video": "Select video to add to the end",
        "error": "Error", "join_error": "The video could not be added.", "unifi": "Unifying and concatenating files...", "wait": "Please wait a moment", "plus": "Adding video", "save_audio": "Save audio", 
        "finalized": "finalized.", "error_extract_audio": "Error extracting audio:", "error_save_capture": "Error saving screenshot:", "error_rotate": "rotation error"
    },

    "de": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Datei", "open": "Video öffnen...", "save": "Speichern unter...", "export": "Video exportieren...", "exit": "Beenden",
        "edit": "Bearbeiten", "undo": "Rückgängig", "redo": "Wiederherstellen", "cut": "Fragment ausschneiden", "copy": "Fragment kopieren", "paste": "Fragment einfügen", "set_start": "Start setzen [A]", "set_end": "Ende setzen [B]", "clear_sel": "Auswahl aufheben", "delete": "Fragment löschen",
        "play": "Abspielen", "pause": "Pause", "stop": "Stopp", "go_start": "Zum Anfang", "go_end": "Zum Ende", "undo-1": "Schritt zurück -1s", "redo+1": "Schritt vor -1s",
        "tools": "Werkzeuge", "join": "Video anhängen...", "rotate": "Drehen +90°", "unrotate": "Drehen -90°", "extract_audio": "Audio extrahieren", "capture": "Frame aufnehmen",
        "help": "Hilfe", "shortcuts": "Tastenkürzel", "about": "Über", "status_ready": "Bereit", "selection": "Auswahl", "none": "Keine",
        "space_key": "Leertaste", "left_arrow": "Linkspfeil", "right_arrow": "Rechtspfeil",
        "main_area_open": "Datei öffnen, um mit der Bearbeitung zu beginnen", "duration": "Dauer", "error_play": "Der Player konnte nicht gestartet werden.", "export_video": "Video exportiert",
        "undo_end": "Rückgängig abgeschlossen.", "redo_end": "Wiederherstellen abgeschlossen.", "undo_no": "Keine weiteren Aktionen zum Rückgängigmachen.", "redo_no": "Keine weiteren Aktionen auszuführen.", "frag_copy": "Fragment in die Zwischenablage kopiert.",
        "attention": "Achtung", "no_clip": "Zwischenablage ist leer.", "no_paste": "Konnte nicht angehängt werden.", "mark": "Zuerst Teil [A-B] markieren.", "error_delete": "Fehler beim Löschen.", "save_photo": "Frame speichern.",
        "success": "Erfolg", "join_success": "Video erfolgreich an das Ende angefügt.", "editing": "BEARBEITUNG", "start_video": "Video starten", "stop_video": "Video stoppen.",
        "no_meta": "Fehler beim Lesen der Metadaten.", "video": "Video", "video_success": "Video erfolgreich gespeichert!", "select_video": "Video zum Anhängen auswählen",
        "error": "Fehler", "join_error": "Das Video konnte nicht hinzugefügt werden.", "unifi": "Dateien werden vereint und verknüpft...", "wait": "Bitte einen Moment warten", "plus": "Video wird hinzugefügt", "save_audio": "Audio speichern",
        "finalized": "abgeschlossen.", "error_extract_audio": "Fehler beim Extrahieren von Audio:", "error_save_capture": "Fehler beim Speichern des Screenshots:", "error_rotate": "Rotationsfehler"
    },

    "sr": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Fajl", "open": "Otvori video...", "save": "Sačuvaj kao...", "export": "Izvezi video...", "exit": "Izlaz",
        "edit": "Izmena", "undo": "Poništi", "redo": "Vrati", "cut": "Iseci fragment", "copy": "Kopiraj fragment", "paste": "Nalepi fragment", "set_start": "Postavi početak [A]", "set_end": "Postavi kraj [B]", "clear_sel": "Očisti izbor", "delete": "Obriši fragment",
        "play": "Reprodukuj", "pause": "Pauziraj", "stop": "Zaustavi", "go_start": "Idi na početak", "go_end": "Idi na kraj", "undo-1": "Korak nazad -1s", "redo+1": "Korak napred +1s",
        "tools": "Alati", "join": "Dodaj video...", "rotate": "Rotiraj +90°", "unrotate": "Rotiraj -90°", "extract_audio": "Izvuci audio", "capture": "Snimi kadar",
        "help": "Pomoć", "shortcuts": "Prečice na tastaturi", "about": "O programu", "status_ready": "Spremno", "selection": "Izbor", "none": "Nema",
        "space_key": "Razmak", "left_arrow": "Strelica levo", "right_arrow": "Strelica desno",
        "main_area_open": "Otvori fajl da bi započeo uređivanje", "duration": "Trajanje", "error_play": "Plejer nije mogao biti pokrenut.", "export_video": "Video izvezen",
        "undo_end": "Poništavanje završeno.", "redo_end": "Vraćanje završeno.", "undo_no": "Nema više radnji za poništavanje.", "redo_no": "Nema više radnji za vraćanje.", "frag_copy": "Fragment kopiran u klipbord.",
        "attention": "Pažnja", "no_clip": "Klipbord je prazan.", "no_paste": "Nije moglo biti zalepljeno.", "mark": "Prvo označi deo [A-B].", "error_delete": "Greška pri brisanju.", "save_photo": "Sačuvaj kadar.",
        "success": "Uspeh", "join_success": "Video uspešno dodat na kraj snimka.", "editing": "UREĐIVANJE", "start_video": "Pokreni video", "stop_video": "Zaustavi video.",
        "no_meta": "Greška pri čitanju metapodataka.", "video": "Video", "video_success": "Video uspešno sačuvan!", "select_video": "Izaberi video za dodavanje na kraj",
        "error": "Greška", "join_error": "Video nije mogao biti dodat.", "unifi": "Objedinjavanje i povezivanje fajlova...", "wait": "Molimo sačekajte trenutak", "plus": "Dodavanje videa", "save_audio": "Sačuvaj audio",
        "finalized": "završeno.", "error_extract_audio": "Greška pri izdvajanju zvuka:", "error_save_capture": "Greška pri čuvanju snimka ekrana:", "error_rotate": "Greška pri rotaciji"
    },

    "ca": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Fitxer", "open": "Obrir vídeo...", "save": "Anomena i desa...", "export": "Exportar vídeo...", "exit": "Sortir",
        "edit": "Edició", "undo": "Desfer", "redo": "Refer", "cut": "Tallar fragment", "copy": "Copiar fragment", "paste": "Enganxar fragment", "set_start": "Marcar inici [A]", "set_end": "Marcar final [B]", "clear_sel": "Netejar selecció", "delete": "Suprimir fragment",
        "play": "Reproduir", "pause": "Pausa", "stop": "Aturar", "go_start": "Anar a l'inici", "go_end": "Anar al final", "undo-1": "Pas enrere -1s", "redo+1": "Pas endavant +1s",
        "tools": "Eines", "join": "Afegir vídeo...", "rotate": "Girar +90°", "unrotate": "Girar -90°", "extract_audio": "Extreure àudio", "capture": "Captura de fotograma",
        "help": "Ajuda", "shortcuts": "Dreceres de teclat", "about": "Quant a", "status_ready": "A punt", "selection": "Selecció", "none": "Cap",
        "space_key": "Espai", "left_arrow": "Fletxa esquerra", "right_arrow": "Fletxa dreta",
        "main_area_open": "Obre un fitxer per començar a editar", "duration": "Durada", "error_play": "No s'ha pogut iniciar el reproductor.", "export_video": "Vídeo exportat",
        "undo_end": "Desfeta completada.", "redo_end": "Refeta completada.", "undo_no": "No hi ha més accions per desfer.", "redo_no": "No hi ha més accions per fer.", "frag_copy": "Fragment copiat al porta-retalls.",
        "attention": "Atenció", "no_clip": "El porta-retalls està buit.", "no_paste": "No s'ha pogut enganxar.", "mark": "Marca primer la part [A-B].", "error_delete": "Error en suprimir.", "save_photo": "Desar fotograma.",
        "success": "Èxit", "join_success": "Vídeo afegit amb èxit al final de la gravació.", "editing": "EDITANT", "start_video": "Iniciar vídeo", "stop_video": "Aturar vídeo.",
        "no_meta": "Error llegint les metadades.", "video": "Vídeo", "video_success": "Vídeo desat correctament!", "select_video": "Selecciona vídeo per afegir al final",
        "error": "Error", "join_error": "No s'ha pogut afegir el vídeo.", "unifi": "Unificant i concatenant fitxers...", "wait": "Si us plau, espereu un moment", "plus": "Afegint vídeo", "save_audio": "Desar àudio",
        "finalized": "finalitzat.", "error_extract_audio": "Error en extreure l'àudio:", "error_save_capture": "Error en desar la captura:", "error_rotate": "error de rotació"
    },

    "es": {
        "title": "JSP Video - Recortador de Vídeo i386",
        "file": "Archivo", "open": "Abrir Vídeo...", "save": "Guardar como...", "export": "Exportar vídeo...",  "exit": "Salir",
        "edit": "Editar", "undo": "Deshacer", "redo": "Rehacer", "cut": "Cortar fragmento", "copy": "Copiar fragmento", "paste": "Pegar fragmento", "set_start": "Marcar Inicio [A]", "set_end": "Marcar Fin [B]", "clear_sel": "Limpiar selección", "delete": "Eliminar fragmento",
        "play": "Reproducir", "pause": "Pausa", "stop": "Parar", "go_start": "Ir al principio", "go_end": "Ir al final", "undo-1": "Retroceder -1s", "redo+1": "Avanzar +1s",
        "tools": "Herramientas", "join": "Añadir vídeo al final...", "rotate": "Rotar +90°", "unrotate": "Rotar -90°", "extract_audio": "Extraer Audio", "capture": "Capturar fotograma",
        "help": "Ayuda", "shortcuts": "Atajos de teclado", "about": "Acerca de", "status_ready": "Listo", "selection": "Selección", "none": "Ninguna",
        "space_key": "Espacio", "left_arrow": "Flecha izquierda", "right_arrow": "Flecha derecha", 
        "main_area_open": "Abre un archivo para empezar a editar", "duration": "Duración", "error_play": "No se puedo iniciar el reproductor", "export_video": "Vídeo exportado",
        "undo_end": "Deshacer completado.", "redo_end": "Rehacer completado.", "undo_no": "No hay más acciones para deshacer.", "redo_no": "No hay más acciones para rehacer.", "frag_copy": "Fragmento copiado al portapaquetes.",
        "attention": "Atención", "no_clip": "El portapapeles está vacío.", "no_paste": "No se pudo pegar.", "mark": "Marca primero la parte [A-B].", "error_delete": "Error al eliminar.", "save_photo": "Guardar fotograma.",
        "success": "Éxito", "join_success": "Vídeo añadido correctamente al final del metraje.", "editing": "EDITANDO", "start_video": "Inicia vídeo", "stop_video": "Parar vídeo.", 
        "no_meta": "Error al leer metadatos.", "video": "Vídeo", "video_success": "¡Vídeo guardado con éxito!", "select_video": "Seleccionar vídeo para añadir al final",
        "error": "Error", "join_error": "No se pudo añadir el vídeo.",  "unifi": "Unificando y concatenando archivos...", "wait": "Espere un momento.", "plus": "Añadiendo vídeo", "save_audio": "Guardar audio", 
        "finalized": "finalizado.", "error_extract_audio": "Error al extraer audio:", "error_save_capture": "Error al guardar captura:", "error_rotate": "error al rotar"
    },

    "bg": {
        "title": "JSP Video - Видео изрязвачка i386",
        "file": "Файл", "open": "Отвори видео...", "save": "Запиши като...", "export": "Експортирай видео...", "exit": "Изход",
        "edit": "Редактиране", "undo": "Отмени", "redo": "Върни", "cut": "Изрежи фрагмент", "copy": "Копирай фрагмент", "paste": "Постави фрагмент", "set_start": "Маркирай начало [A]", "set_end": "Маркирай край [B]", "clear_sel": "Изчисти селекцията", "delete": "Изтрий фрагмент",
        "play": "Възпроизвеждане", "pause": "Пауза", "stop": "Стоп", "go_start": "Към началото", "go_end": "Към края", "undo-1": "Назад -1с", "redo+1": "Напред +1с",
        "tools": "Инструменти", "join": "Добави видео в края...", "rotate": "Завърти +90°", "unrotate": "Завърти -90°", "extract_audio": "Извлечи аудио", "capture": "Улови кадър",
        "help": "Помощ", "shortcuts": "Клавишни комбинации", "about": "Относно", "status_ready": "Готов", "selection": "Селекция", "none": "Няма",
        "space_key": "Интервал", "left_arrow": "Лява стрелка", "right_arrow": "Дясна стрелка", 
        "main_area_open": "Отворете файл, за да започнете редактиране", "duration": "Продължителност", "error_play": "Плейърът не можа да се стартира.", "export_video": "Видео експортирано", 
        "undo_end": "Отмяната е завършена.", "redo_end": "Връщането е завършено.", "undo_no": "Няма повече действия за отмяна.", "redo_no": "Няма повече действия за връщане.", "frag_copy": "Фрагментът е копиран в клипборда.", 
        "attention": "Внимание", "no_clip": "Клипбордът е празен.", "no_paste": "Не можа да се постави.", "mark": "Първо маркирайте част [A-B].", "error_delete": "Грешка при изтриване.", "save_photo": "Запази кадър.",
        "success": "Успех", "join_success": "Видеоклипът е успешно добавен в края.", "editing": "РЕДАКТИРАНЕ", "start_video": "Стартирай видео", "stop_video": "Спри видео.", 
        "no_meta": "Грешка при четене на метаданни.", "video": "Видео", "video_success": "Видеоклипът е записан успешно!", "select_video": "Изберете видео за добавяне в края",
        "error": "Грешка", "join_error": "Видеоклипът не можа да бъде добавен.", "unifi": "Обединяване и конкатениране на файлове...", "wait": "Моля, изчакайте малко", "plus": "Добавяне на видео", "save_audio": "Запази аудио", "finalized": "Завършено.", "error_extract_audio": "Грешка при извличане на аудио:", "error_save_capture": "Грешка при запис на екранна снимка:", "error_rotate": "Грешка при завъртане"
    },

 
    "el": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Αρχείο", "open": "Άνοιγμα βίντεο...", "save": "Αποθήκευση ως...", "export": "Εξαγωγή βίντεο...", "exit": "Έξοδος",
        "edit": "Επεξεργασία", "undo": "Αναίρεση", "redo": "Ακύρωση αναίρεσης", "cut": "Αποκοπή τμήματος", "copy": "Αντιγραφή τμήματος", "paste": "Επικόλληση τμήματος", "set_start": "Ορισμός αρχής [A]", "set_end": "Ορισμός τέλους [B]", "clear_sel": "Καθαρισμός επιλογής", "delete": "Διαγραφή τμήματος",
        "play": "Αναπαραγωγή", "pause": "Παύση", "stop": "Διακοπή", "go_start": "Μετάβαση στην αρχή", "go_end": "Μετάβαση στο τέλος", "undo-1": "Πίσω -1δ", "redo+1": "Εμπρός +1δ",
        "tools": "Εργαλεία", "join": "Προσθήκη βίντεο στο τέλος...", "rotate": "Περιστροφή +90°", "unrotate": "Περιστροφή -90°", "extract_audio": "Εξαγωγή ήχου", "capture": "Λήψη στιγμιότυπου",
        "help": "Βοήθεια", "shortcuts": "Συντομεύσεις πληκτρολογίου", "about": "Σχετικά", "status_ready": "Έτοιμο", "selection": "Επιλογή", "none": "Καμία",
        "space_key": "Διάστημα", "left_arrow": "Αριστερό βέλος", "right_arrow": "Δεξί βέλος", 
        "main_area_open": "Ανοίξτε ένα αρχείο για να ξεκινήσετε την επεξεργασία", "duration": "Διάρκεια", "error_play": "Δεν ήταν δυνατή η εκκίνηση του player.", "export_video": "Το βίντεο εξήχθη", 
        "undo_end": "Η αναίρεση ολοκληρώθηκε.", "redo_end": "Η ακύρωση αναίρεσης ολοκληρώθηκε.", "undo_no": "Δεν υπάρχουν άλλες ενέργειες για αναίρεση.", "redo_no": "Δεν υπάρχουν άλλες ενέργειες για επανάληψη.", "frag_copy": "Το τμήμα αντιγράφηκε στο πρόχειρο.", 
        "attention": "Προσοχή", "no_clip": "Το πρόχειρο είναι άδειο.", "no_paste": "Δεν ήταν δυνατή η επικόλληση.", "mark": "Ορίστε πρώτα το τμήμα [A-B].", "error_delete": "Σφάλμα κατά τη διαγραφή.", "save_photo": "Αποθήκευση στιγμιότυπου.",
        "success": "Επιτυχία", "join_success": "Το βίντεο προστέθηκε επιτυχώς στο τέλος.", "editing": "ΕΠΕΞΕΡΓΑΣΙΑ", "start_video": "Έναρξη βίντεο", "stop_video": "Διακοπή βίντεο.", 
        "no_meta": "Σφάλμα ανάγνωσης μεταδεδομένων.", "video": "Βίντεο", "video_success": "Το βίντεο αποθηκεύτηκε επιτυχώς!", "select_video": "Επιλέξτε βίντεο για προσθήκη στο τέλος",
        "error": "Σφάλμα", "join_error": "Δεν ήταν δυνατή η προσθήκη του βίντεο.", "unifi": "Ενοποίηση και συνένωση αρχείων...", "wait": "Παρακαλώ περιμένετε...", "plus": "Προσθήκη βίντεο", "save_audio": "Αποθήκευση ήχου", "finalized": "Ολοκληρώθηκε.", "error_extract_audio": "Σφάλμα εξαγωγής ήχου:", "error_save_capture": "Σφάλμα αποθήκευσης στιγμιότυπου:", "error_rotate": "Σφάλμα περιστροφής"
    },

    "eu": {
        "title": "JSP Video - Bideo Ebakitzailea i386",
        "file": "Fitxategia", "open": "Ireki bideoa...", "save": "Gorde honela...", "export": "Esportatu bideoa...", "exit": "Irten",
        "edit": "Editatu", "undo": "Desegin", "redo": "Berregin", "cut": "Moztu zatia", "copy": "Kopiatu zatia", "paste": "Itsatsi zatia", "set_start": "Markatu hasiera [A]", "set_end": "Markatu amaiera [B]", "clear_sel": "Garbitu hautapena", "delete": "Ezabatu zatia",
        "play": "Erreproduzitu", "pause": "Pausatu", "stop": "Gelditu", "go_start": "Joan hasierara", "go_end": "Joan amaierara", "undo-1": "Atzera -1s", "redo+1": "Aurrera +1s",
        "tools": "Tresnak", "join": "Gehitu bideoa amaieran...", "rotate": "Biratu +90°", "unrotate": "Biratu -90°", "extract_audio": "Atera audioa", "capture": "Kapturatu fotograma",
        "help": "Laguntza", "shortcuts": "Teklatu lasterbideak", "about": "Honi buruz", "status_ready": "Prest", "selection": "Hautapena", "none": "Bat ere ez",
        "space_key": "Zuriunea", "left_arrow": "Ezker gezia", "right_arrow": "Eskuin gezia", 
        "main_area_open": "Ireki fitxategi bat editatzen hasteko", "duration": "Iraupena", "error_play": "Ezin izan da erreproduzigailua abiarazi.", "export_video": "Bideoa esportatuta", 
        "undo_end": "Desegitea osatuta.", "redo_end": "Berregitea osatuta.", "undo_no": "Ez dago desegiteko ekintza gehiago.", "redo_no": "Ez dago berregiteko ekintza gehiago.", "frag_copy": "Zatia arbelean kopiatuta.", 
        "attention": "Kontuz", "no_clip": "Arbela hutsik dago.", "no_paste": "Ezin izan da itsatsi.", "mark": "Markatu lehenik [A-B] zatia.", "error_delete": "Errorea ezabatzean.", "save_photo": "Gorde fotograma.",
        "success": "Arrakasta", "join_success": "Bideoa ongi gehitu da amaieran.", "editing": "EDITATZEN", "start_video": "Hasi bideoa", "stop_video": "Gelditu bideoa.", 
        "no_meta": "Errorea metadatuak irakurtzean.", "video": "Bideoa", "video_success": "Bideoa ongi gordeta!", "select_video": "Hautatu amaieran gehitzeko bideoa",
        "error": "Errorea", "join_error": "Ezin izan da bideoa gehitu.", "unifi": "Fitxategiak bateratzen eta elkartzen...", "wait": "Itxaron une batez", "plus": "Bideoa gehitzen", "save_audio": "Gorde audioa", "finalized": "Amaituta.", "error_extract_audio": "Errorea audioa ateratzean:", "error_save_capture": "Errorea pantaila-argazkia gordetzean:", "error_rotate": "Errorea biratzean"
    },

    "fr": {
        "title": "JSP Video - Découpeur Vidéo i386",
        "file": "Fichier", "open": "Ouvrir vidéo...", "save": "Enregistrer sous...", "export": "Exporter vidéo...", "exit": "Quitter",
        "edit": "Édition", "undo": "Annuler", "redo": "Rétablir", "cut": "Couper fragment", "copy": "Copier fragment", "paste": "Coller fragment", "set_start": "Marquer début [A]", "set_end": "Marquer fin [B]", "clear_sel": "Effacer sélection", "delete": "Supprimer fragment",
        "play": "Lire", "pause": "Pause", "stop": "Arrêter", "go_start": "Aller au début", "go_end": "Aller à la fin", "undo-1": "Reculer -1s", "redo+1": "Avancer +1s",
        "tools": "Outils", "join": "Ajouter vidéo à la fin...", "rotate": "Pivoter +90°", "unrotate": "Pivoter -90°", "extract_audio": "Extraire audio", "capture": "Capturer image",
        "help": "Aide", "shortcuts": "Raccourcis clavier", "about": "À propos", "status_ready": "Prêt", "selection": "Sélection", "none": "Aucune",
        "space_key": "Espace", "left_arrow": "Flèche gauche", "right_arrow": "Flèche droite", 
        "main_area_open": "Ouvrez un fichier pour commencer l'édition", "duration": "Durée", "error_play": "Impossible de démarrer le lecteur.", "export_video": "Vidéo exportée", 
        "undo_end": "Annulation terminée.", "redo_end": "Rétablissement terminé.", "undo_no": "Plus aucune action à annuler.", "redo_no": "Plus aucune action à rétablir.", "frag_copy": "Fragment copié dans le presse-papier.", 
        "attention": "Attention", "no_clip": "Le presse-papier est vide.", "no_paste": "Impossible de coller.", "mark": "Marquez d'abord la partie [A-B].", "error_delete": "Erreur lors de la suppression.", "save_photo": "Enregistrer image.",
        "success": "Succès", "join_success": "Vidéo ajoutée avec succès à la fin du métrage.", "editing": "ÉDITION", "start_video": "Démarrer vidéo", "stop_video": "Arrêter vidéo.", 
        "no_meta": "Erreur de lecture des métadonnées.", "video": "Vidéo", "video_success": "Vidéo enregistrée avec succès !", "select_video": "Sélectionner la vidéo à ajouter à la fin",
        "error": "Erreur", "join_error": "Impossible d'ajouter la vidéo.", "unifi": "Unification et concaténation des fichiers...", "wait": "Veuillez patienter un instant", "plus": "Ajout de la vidéo", "save_audio": "Enregistrer audio", "finalized": "Terminé.", "error_extract_audio": "Erreur lors de l'extraction audio :", "error_save_capture": "Erreur lors de l'enregistrement de la capture :", "error_rotate": "Erreur de rotation"
    },

    "gl": {
        "title": "JSP Video - Recortador de Vídeo i386",
        "file": "Ficheiro", "open": "Abrir vídeo...", "save": "Gardar como...", "export": "Exportar vídeo...", "exit": "Saír",
        "edit": "Editar", "undo": "Desfacer", "redo": "Refacer", "cut": "Cortar fragmento", "copy": "Copiar fragmento", "paste": "Pegar fragmento", "set_start": "Marcar inicio [A]", "set_end": "Marcar fin [B]", "clear_sel": "Limpar selección", "delete": "Eliminar fragmento",
        "play": "Reproducir", "pause": "Pausa", "stop": "Parar", "go_start": "Ir ao principio", "go_end": "Ir ao final", "undo-1": "Retroceder -1s", "redo+1": "Avanzar +1s",
        "tools": "Ferramentas", "join": "Engadir vídeo ao final...", "rotate": "Rotar +90°", "unrotate": "Rotar -90°", "extract_audio": "Extraer audio", "capture": "Capturar fotograma",
        "help": "Axuda", "shortcuts": "Atallos de teclado", "about": "Acerca de", "status_ready": "Listo", "selection": "Selección", "none": "Ningunha",
        "space_key": "Espazo", "left_arrow": "Frecha esquerda", "right_arrow": "Frecha dereita", 
        "main_area_open": "Abre un ficheiro para comezar a editar", "duration": "Duración", "error_play": "Non se puido iniciar o reprodutor.", "export_video": "Vídeo exportado", 
        "undo_end": "Desfacer completado.", "redo_end": "Refacer completado.", "undo_no": "Non hai máis accións para desfacer.", "redo_no": "Non hai máis accións para refacer.", "frag_copy": "Fragmento copiado ao portapapeis.", 
        "attention": "Atención", "no_clip": "O portapapeis está baleiro.", "no_paste": "Non se puido pegar.", "mark": "Marca primeiro a parte [A-B].", "error_delete": "Erro ao eliminar.", "save_photo": "Gardar fotograma.",
        "success": "Éxito", "join_success": "Vídeo engadido correctamente ao final do metraxe.", "editing": "EDITANDO", "start_video": "Iniciar vídeo", "stop_video": "Parar vídeo.", 
        "no_meta": "Erro ao ler metadatos.", "video": "Vídeo", "video_success": "Vídeo gardado con éxito!", "select_video": "Seleccionar vídeo para engadir ao final",
        "error": "Erro", "join_error": "Non se puido engadir o vídeo.", "unifi": "Unificando e concatenando ficheiros...", "wait": "Agarde un momento", "plus": "Engadindo vídeo", "save_audio": "Gardar audio", "finalized": "Finalizado.", "error_extract_audio": "Erro ao extraer o audio:", "error_save_capture": "Erro ao gardar a captura:", "error_rotate": "Erro ao rotar"
    },

    "hi": {
        "title": "JSP Video - वीडियो क्लिपर i386",
        "file": "फ़ाइल", "open": "वीडियो खोलें...", "save": "इस रूप में सहेजें...", "export": "वीडियो निर्यात करें...", "exit": "बाहर निकलें",
        "edit": "संपादित करें", "undo": "पूर्ववत करें", "redo": "फिर से करें", "cut": "खंड काटें", "copy": "खंड कॉपी करें", "paste": "खंड चिपकाएँ", "set_start": "आरंभ चिह्न [A]", "set_end": "अंत चिह्न [B]", "clear_sel": "चयन साफ़ करें", "delete": "खंड हटाएं",
        "play": "चलाएँ", "pause": "विराम", "stop": "रोकें", "go_start": "शुरुआत में जाएँ", "go_end": "अंत में जाएँ", "undo-1": "पीछे -1स", "redo+1": "आगे +1स",
        "tools": "उपकरण", "join": "अंत में वीडियो जोड़ें...", "rotate": "घुमाएँ +90°", "unrotate": "घुमाएँ -90°", "extract_audio": "ऑडियो निकालें", "capture": "फ्रेम कैप्चर करें",
        "help": "मदद", "shortcuts": "कीबोर्ड शॉर्टकट", "about": "हमारे बारे में", "status_ready": "तैयार", "selection": "चयन", "none": "कोई नहीं",
        "space_key": "स्पेस", "left_arrow": "बायाँ तीर", "right_arrow": "दायाँ तीर", 
        "main_area_open": "संपादन शुरू करने के लिए एक फ़ाइल खोलें", "duration": "अवधि", "error_play": "प्लेयर शुरू नहीं किया जा सका।", "export_video": "वीडियो निर्यात किया गया", 
        "undo_end": "पूर्ववत पूरा हुआ।", "redo_end": "फिर से किया गया।", "undo_no": "पूर्ववत करने के लिए और कोई क्रिया नहीं है।", "redo_no": "फिर से करने के लिए और कोई क्रिया नहीं है।", "frag_copy": "खंड क्लिपबोर्ड पर कॉपी किया गया।", 
        "attention": "ध्यान दें", "no_clip": "क्लिपबोर्ड खाली है।", "no_paste": "चिपकाया नहीं जा सका।", "mark": "पहले [A-B] भाग को चिह्नित करें।", "error_delete": "हटाने में त्रुटि।", "save_photo": "फ्रेम सहेजें।",
        "success": "सफलता", "join_success": "वीडियो को सफलतापूर्वक अंत में जोड़ दिया गया।", "editing": "संपादन", "start_video": "वीडियो शुरू करें", "stop_video": "वीडियो रोकें।", 
        "no_meta": "मेटाडेटा पढ़ने में त्रुटि।", "video": "वीडियो", "video_success": "वीडियो सफलतापूर्वक सहेजा गया!", "select_video": "अंत में जोड़ने के लिए वीडियो चुनें",
        "error": "त्रुटि", "join_error": "वीडियो नहीं जोड़ा जा सका।", "unifi": "फ़ाइलों को एकीकृत और संयोजित किया जा रहा है...", "wait": "कृपया थोड़ा प्रतीक्षा करें", "plus": "वीडियो जोड़ा जा रहा है", "save_audio": "ऑडियो सहेजें", "finalized": "पूर्ण हुआ।", "error_extract_audio": "ऑडियो निकालने में त्रुटि:", "error_save_capture": "स्क्रीनशॉट सहेजने में त्रुटि:", "error_rotate": "रोटेशन त्रुटि"
    },

    "hr": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Datoteka", "open": "Otvori video...", "save": "Spremi kao...", "export": "Izvezi video...", "exit": "Izlaz",
        "edit": "Uredi", "undo": "Poništi", "redo": "Ponovi", "cut": "Izreži isječak", "copy": "Kopiraj isječak", "paste": "Zalijepi isječak", "set_start": "Označi početak [A]", "set_end": "Označi kraj [B]", "clear_sel": "Očisti odabir", "delete": "Izbriši isječak",
        "play": "Reproduciraj", "pause": "Pauza", "stop": "Zaustavi", "go_start": "Idi na početak", "go_end": "Idi na kraj", "undo-1": "Nazad -1s", "redo+1": "Naprijed +1s",
        "tools": "Alati", "join": "Dodaj video na kraj...", "rotate": "Rotiraj +90°", "unrotate": "Rotiraj -90°", "extract_audio": "Izdvoji audio", "capture": "Snimi kadar",
        "help": "Pomoć", "shortcuts": "Tipkovnički prečaci", "about": "O programu", "status_ready": "Spremno", "selection": "Odabir", "none": "Ništa",
        "space_key": "Razmak", "left_arrow": "Lijeva strelica", "right_arrow": "Desna strelica", 
        "main_area_open": "Otvorite datoteku za početak uređivanja", "duration": "Trajanje", "error_play": "Reproduktor se nije mogao pokrenuti.", "export_video": "Video izvezen", 
        "undo_end": "Poništavanje dovršeno.", "redo_end": "Ponavljanje dovršeno.", "undo_no": "Nema više radnji za poništiti.", "redo_no": "Nema više radnji za ponoviti.", "frag_copy": "Isječak kopiran u međuspremnik.", 
        "attention": "Pažnja", "no_clip": "Međuspremnik je prazan.", "no_paste": "Nije se moglo zalijepiti.", "mark": "Prvo označite dio [A-B].", "error_delete": "Greška pri brisanju.", "save_photo": "Spremi kadar.",
        "success": "Uspjeh", "join_success": "Video uspješno dodan na kraj.", "editing": "UREĐIVANJE", "start_video": "Pokreni video", "stop_video": "Zaustavi video.", 
        "no_meta": "Greška pri čitanju metapodataka.", "video": "Video", "video_success": "Video uspješno spremljen!", "select_video": "Odaberite video za dodavanje na kraj",
        "error": "Greška", "join_error": "Video se nije mogao dodati.", "unifi": "Objedinjavanje i spajanje datoteka...", "wait": "Molimo pričekajte trenutak", "plus": "Dodavanje videa", "save_audio": "Spremi audio", "finalized": "Završeno.", "error_extract_audio": "Pogreška pri izdvajanju zvuka:", "error_save_capture": "Pogreška pri spremanju snimke zaslona:", "error_rotate": "Pogreška pri rotaciji"
    },

    "hu": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Fájl", "open": "Videó megnyitása...", "save": "Mentés másként...", "export": "Videó exportálása...", "exit": "Kilépés",
        "edit": "Szerkesztés", "undo": "Visszavonás", "redo": "Újra", "cut": "Részlet kivágása", "copy": "Részlet másolása", "paste": "Részlet beillesztése", "set_start": "Kezdet jelölése [A]", "set_end": "Vége jelölése [B]", "clear_sel": "Kijelölés törlése", "delete": "Részlet törlése",
        "play": "Lejátszás", "pause": "Szünet", "stop": "Állj", "go_start": "Ugrás az elejére", "go_end": "Ugrás a végére", "undo-1": "Vissza -1mp", "redo+1": "Előre +1mp",
        "tools": "Eszközök", "join": "Videó hozzáfűzése...", "rotate": "Forgatás +90°", "unrotate": "Forgatás -90°", "extract_audio": "Hang kinyerése", "capture": "Képkocka mentése",
        "help": "Súgó", "shortcuts": "Gyorsbillentyűk", "about": "Névjegy", "status_ready": "Kész", "selection": "Kijelölés", "none": "Nincs",
        "space_key": "Szóköz", "left_arrow": "Bal nyíl", "right_arrow": "Jobb nyíl", 
        "main_area_open": "Nyisson meg egy fájlt a szerkesztéshez", "duration": "Időtartam", "error_play": "A lejátszó nem indítható el.", "export_video": "Videó exportálva", 
        "undo_end": "Visszavonás kész.", "redo_end": "Újra kész.", "undo_no": "Nincs több visszavonható művelet.", "redo_no": "Nincs több újra elvégezhető művelet.", "frag_copy": "Részlet a vágólapra másolva.", 
        "attention": "Figyelem", "no_clip": "A vágólap üres.", "no_paste": "Nem sikerült beilleszteni.", "mark": "Először jelölje ki az [A-B] részt.", "error_delete": "Hiba a törlésnél.", "save_photo": "Képkocka mentése.",
        "success": "Siker", "join_success": "A videó sikeresen hozzáfűzve.", "editing": "SZERKESZTÉS", "start_video": "Videó indítása", "stop_video": "Videó leállítása.", 
        "no_meta": "Hiba a metaadatok olvasásakor.", "video": "Videó", "video_success": "Videó sikeresen mentve!", "select_video": "Válasszon videót a hozzáfűzéshez",
        "error": "Hiba", "join_error": "A videót nem sikerült hozzáadni.", "unifi": "Fájlok egyesítése és összefűzése...", "wait": "Kérjük, várjon egy pillanatot", "plus": "Videó hozzáadása", "save_audio": "Hang mentése", "finalized": "Kész.", "error_extract_audio": "Hiba a hangkivonás során:", "error_save_capture": "Hiba a képernyőkép mentésekor:", "error_rotate": "Forgatási hiba"
    },

    "is": {
        "title": "JSP Video - Myndbandaklippari i386",
        "file": "Skrá", "open": "Opna myndband...", "save": "Vista sem...", "export": "Flytja út myndband...", "exit": "Hætta",
        "edit": "Breyta", "undo": "Afturkalla", "redo": "Endurgera", "cut": "Klippa hluta", "copy": "Afrita hluta", "paste": "Líma hluta", "set_start": "Setja upphaf [A]", "set_end": "Setja enda [B]", "clear_sel": "Hreinsa val", "delete": "Eyða hluta",
        "play": "Spila", "pause": "Hlé", "stop": "Stöðva", "go_start": "Fara í upphaf", "go_end": "Fara í enda", "undo-1": "Aftur á bak -1s", "redo+1": "Áfram +1s",
        "tools": "Verkfæri", "join": "Bæta við myndbandi...", "rotate": "Snúa +90°", "unrotate": "Snúa -90°", "extract_audio": "Útdráttur hljóðs", "capture": "Taka mynd af ramma",
        "help": "Hjálp", "shortcuts": "Flýtilyklar", "about": "Um forritið", "status_ready": "Tilbúið", "selection": "Val", "none": "Ekkert",
        "space_key": "Bil", "left_arrow": "Vinstri ör", "right_arrow": "Hægri ör", 
        "main_area_open": "Opnaðu skrá til að hefja klippingu", "duration": "Lengd", "error_play": "Ekki tókst að ræsa spilarann.", "export_video": "Myndband útflutt", 
        "undo_end": "Afturköllun lokið.", "redo_end": "Endurgerð lokið.", "undo_no": "Engar frekari aðgerðir til að afturkalla.", "redo_no": "Engar frekari aðgerðir til að endurgera.", "frag_copy": "Hluti afritaður á klemmuspjald.", 
        "attention": "Athugið", "no_clip": "Klemmuspjaldið er tómt.", "no_paste": "Ekki tókst að líma.", "mark": "Merktu fyrst [A-B] hluta.", "error_delete": "Villa við eyðingu.", "save_photo": "Vista ramma.",
        "success": "Árangur", "join_success": "Myndbandi bætt við í lokin.", "editing": "KLIPPING", "start_video": "Spila myndband", "stop_video": "Stöðva myndband.", 
        "no_meta": "Villa við lestur lýsigagna.", "video": "Myndband", "video_success": "Myndband vistað!", "select_video": "Veldu myndband til að bæta við",
        "error": "Villa", "join_error": "Ekki tókst að bæta við myndbandi.", "unifi": "Sameina skrár...", "wait": "Vinsamlegast bíðið", "plus": "Bætir við myndbandi", "save_audio": "Vista hljóð", "finalized": "Lokið.", "error_extract_audio": "Villa við að draga út hljóð:", "error_save_capture": "Villa við að vista skjámynd:", "error_rotate": "Snúningsvilla"
    },

    "it": {
        "title": "JSP Video - Taglia Video i386",
        "file": "File", "open": "Apri video...", "save": "Salva come...", "export": "Esporta video...", "exit": "Esci",
        "edit": "Modifica", "undo": "Annulla", "redo": "Ripristina", "cut": "Taglia frammento", "copy": "Copia frammento", "paste": "Incolla frammento", "set_start": "Segna inizio [A]", "set_end": "Segna fine [B]", "clear_sel": "Pulisci selezione", "delete": "Elimina frammento",
        "play": "Riproduci", "pause": "Pausa", "stop": "Ferma", "go_start": "Vai all'inizio", "go_end": "Vai alla fine", "undo-1": "Indietro -1s", "redo+1": "Avanti +1s",
        "tools": "Strumenti", "join": "Aggiungi video alla fine...", "rotate": "Ruota +90°", "unrotate": "Ruota -90°", "extract_audio": "Estrai audio", "capture": "Cattura fotogramma",
        "help": "Aiuto", "shortcuts": "Scorciatoie tastiera", "about": "Informazioni", "status_ready": "Pronto", "selection": "Selezione", "none": "Nessuna",
        "space_key": "Spazio", "left_arrow": "Freccia sinistra", "right_arrow": "Freccia destra", 
        "main_area_open": "Apri un file per iniziare a modificare", "duration": "Durata", "error_play": "Impossibile avviare il riproduttore.", "export_video": "Video esportato", 
        "undo_end": "Annullamento completato.", "redo_end": "Ripristino completato.", "undo_no": "Nessuna azione da annullare.", "redo_no": "Nessuna azione da ripristinare.", "frag_copy": "Frammento copiato negli appunti.", 
        "attention": "Attenzione", "no_clip": "Appunti vuoti.", "no_paste": "Impossibile incollare.", "mark": "Segna prima la parte [A-B].", "error_delete": "Errore durante l'eliminazione.", "save_photo": "Salva fotogramma.",
        "success": "Successo", "join_success": "Video aggiunto con successo alla fine.", "editing": "MODIFICA", "start_video": "Avvia video", "stop_video": "Ferma video.", 
        "no_meta": "Errore nella lettura dei metadati.", "video": "Video", "video_success": "Video salvato con successo!", "select_video": "Seleziona video da aggiungere alla fine",
        "error": "Errore", "join_error": "Impossibile aggiungere il video.", "unifi": "Unificazione e concatenazione file...", "wait": "Attendere un momento", "plus": "Aggiunta video", "save_audio": "Salva audio", "finalized": "Completato.", "error_extract_audio": "Errore durante l'estrazione audio:", "error_save_capture": "Errore durante il salvataggio dello screenshot:", "error_rotate": "Errore di rotazione"
    },

    "ja": {
        "title": "JSP Video - ビデオクリッパー i386",
        "file": "ファイル", "open": "ビデオを開く...", "save": "名前を付けて保存...", "export": "ビデオを書き出し...", "exit": "終了",
        "edit": "編集", "undo": "元に戻す", "redo": "やり直し", "cut": "フラグメントを切り取り", "copy": "フラグメントをコピー", "paste": "フラグメントを貼り付け", "set_start": "開始点 [A]", "set_end": "終了点 [B]", "clear_sel": "選択を解除", "delete": "フラグメントを削除",
        "play": "再生", "pause": "一時停止", "stop": "停止", "go_start": "先頭へ", "go_end": "最後へ", "undo-1": "戻る -1秒", "redo+1": "進む +1秒",
        "tools": "ツール", "join": "ビデオを末尾に追加...", "rotate": "回転 +90°", "unrotate": "回転 -90°", "extract_audio": "音声を抽出", "capture": "フレームをキャプチャ",
        "help": "ヘルプ", "shortcuts": "キーボードショートカット", "about": "バージョン情報", "status_ready": "準備完了", "selection": "選択範囲", "none": "なし",
        "space_key": "スペースキー", "left_arrow": "左矢印", "right_arrow": "右矢印", 
        "main_area_open": "編集を開始するにはファイルを開いてください", "duration": "長さ", "error_play": "プレイヤーを起動できませんでした。", "export_video": "ビデオを書き出しました", 
        "undo_end": "元に戻しました。", "redo_end": "やり直しました。", "undo_no": "これ以上戻せません。", "redo_no": "これ以上やり直せません。", "frag_copy": "クリップボードにコピーしました。", 
        "attention": "注意", "no_clip": "クリップボードは空です。", "no_paste": "貼り付けに失敗しました。", "mark": "先に [A-B] 範囲を指定してください。", "error_delete": "削除中にエラーが発生しました。", "save_photo": "フレームを保存。",
        "success": "成功", "join_success": "ビデオの末尾に追加しました。", "editing": "編集モード", "start_video": "ビデオ再生", "stop_video": "ビデオ停止。", 
        "no_meta": "メタデータの読み込みエラー。", "video": "ビデオ", "video_success": "保存完了！", "select_video": "末尾に追加するビデオを選択",
        "error": "エラー", "join_error": "ビデオを追加できませんでした。", "unifi": "ファイルを統合中...", "wait": "少々お待ちください", "plus": "ビデオ追加中", "save_audio": "音声を保存", "finalized": "完了しました。", "error_extract_audio": "オーディオ抽出エラー:", "error_save_capture": "スクリーンショット保存エラー:", "error_rotate": "回転エラー"
    },

    "nl": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Bestand", "open": "Video openen...", "save": "Opslaan als...", "export": "Video exporteren...", "exit": "Afsluiten",
        "edit": "Bewerken", "undo": "Ongedaan maken", "redo": "Opnieuw", "cut": "Fragment knippen", "copy": "Fragment kopiëren", "paste": "Fragment plakken", "set_start": "Begin markeren [A]", "set_end": "Einde markeren [B]", "clear_sel": "Selectie wissen", "delete": "Fragment verwijderen",
        "play": "Afspelen", "pause": "Pauze", "stop": "Stoppen", "go_start": "Naar begin", "go_end": "Naar einde", "undo-1": "Terug -1s", "redo+1": "Vooruit +1s",
        "tools": "Gereedschap", "join": "Video aan einde toevoegen...", "rotate": "Draaien +90°", "unrotate": "Draaien -90°", "extract_audio": "Audio extraheren", "capture": "Frame vastleggen",
        "help": "Help", "shortcuts": "Sneltoetsen", "about": "Over", "status_ready": "Gereed", "selection": "Selectie", "none": "Geen",
        "space_key": "Spatiebalk", "left_arrow": "Pijl naar links", "right_arrow": "Pijl naar rechts", 
        "main_area_open": "Open een bestand om te beginnen met bewerken", "duration": "Duur", "error_play": "De speler kon niet worden gestart.", "export_video": "Video geëxporteerd", 
        "undo_end": "Ongedaan maken voltooid.", "redo_end": "Opnieuw voltooid.", "undo_no": "Geen acties om ongedaan te maken.", "redo_no": "Geen acties om opnieuw te doen.", "frag_copy": "Fragment gekopieerd naar klembord.", 
        "attention": "Let op", "no_clip": "Het klembord is leeg.", "no_paste": "Kon niet plakken.", "mark": "Markeer eerst het [A-B] deel.", "error_delete": "Fout bij verwijderen.", "save_photo": "Frame opslaan.",
        "success": "Succes", "join_success": "Video succesvol aan het einde toegevoegd.", "editing": "BEWERKEN", "start_video": "Video starten", "stop_video": "Video stoppen.", 
        "no_meta": "Fout bij lezen metadata.", "video": "Video", "video_success": "Video succesvol opgeslagen!", "select_video": "Selecteer video om aan einde toe te voegen",
        "error": "Fout", "join_error": "De video kon niet worden toegevoegd.", "unifi": "Bestanden samenvoegen...", "wait": "Even geduld a.u.b.", "plus": "Video toevoegen", "save_audio": "Audio opslaan", "finalized": "Voltooid.", "error_extract_audio": "Fout bij audio-extractie:", "error_save_capture": "Fout bij opslaan schermafbeelding:", "error_rotate": "Rotatiefout"
    },

    "pl": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Plik", "open": "Otwórz wideo...", "save": "Zapisz jako...", "export": "Eksportuj wideo...", "exit": "Wyjdź",
        "edit": "Edycja", "undo": "Cofnij", "redo": "Ponów", "cut": "Wytnij fragment", "copy": "Skopiuj fragment", "paste": "Wklej fragment", "set_start": "Ustaw początek [A]", "set_end": "Ustaw koniec [B]", "clear_sel": "Wyczyść zaznaczenie", "delete": "Usuń fragment",
        "play": "Odtwórz", "pause": "Pauza", "stop": "Zatrzymaj", "go_start": "Do początku", "go_end": "Do końca", "undo-1": "Wstecz -1s", "redo+1": "Do przodu +1s",
        "tools": "Narzędzia", "join": "Dodaj wideo na koniec...", "rotate": "Obróć +90°", "unrotate": "Obróć -90°", "extract_audio": "Wyodrębnij audio", "capture": "Przechwyć klatkę",
        "help": "Pomoc", "shortcuts": "Skróty klawiszowe", "about": "O programie", "status_ready": "Gotowe", "selection": "Zaznaczenie", "none": "Brak",
        "space_key": "Spacja", "left_arrow": "Strzałka w lewo", "right_arrow": "Strzałka w prawo", 
        "main_area_open": "Otwórz plik, aby rozpocząć edycję", "duration": "Czas trwania", "error_play": "Nie można uruchomić odtwarzacza.", "export_video": "Wideo wyeksportowane", 
        "undo_end": "Cofnięto.", "redo_end": "Ponowiono.", "undo_no": "Brak akcji do cofnięcia.", "redo_no": "Brak akcji do ponowienia.", "frag_copy": "Fragment skopiowany do schowka.", 
        "attention": "Uwaga", "no_clip": "Schowek jest pusty.", "no_paste": "Nie można wkleić.", "mark": "Najpierw zaznacz część [A-B].", "error_delete": "Błąd podczas usuwania.", "save_photo": "Zapisz klatkę.",
        "success": "Sukces", "join_success": "Wideo pomyślnie dodane na koniec.", "editing": "EDYCJA", "start_video": "Uruchom wideo", "stop_video": "Zatrzymaj wideo.", 
        "no_meta": "Błąd odczytu metadanych.", "video": "Wideo", "video_success": "Wideo zapisane pomyślnie!", "select_video": "Wybierz wideo do dodania na koniec",
        "error": "Błąd", "join_error": "Nie można dodać wideo.", "unifi": "Łączenie plików...", "wait": "Proszę czekać", "plus": "Dodawanie wideo", "save_audio": "Zapisz audio","finalized": "Zakończono.", "error_extract_audio": "Błąd podczas wyodrębniania dźwięku:", "error_save_capture": "Błąd podczas zapisywania zrzutu ekranu:", "error_rotate": "Błąd obrotu"
    },

    "pt": {
        "title": "JSP Video - Cortador de Vídeo i386",
        "file": "Ficheiro", "open": "Abrir vídeo...", "save": "Guardar como...", "export": "Exportar vídeo...", "exit": "Sair",
        "edit": "Editar", "undo": "Desfazer", "redo": "Refazer", "cut": "Cortar fragmento", "copy": "Copiar fragmento", "paste": "Colar fragmento", "set_start": "Marcar início [A]", "set_end": "Marcar fim [B]", "clear_sel": "Limpar seleção", "delete": "Eliminar fragmento",
        "play": "Reproduzir", "pause": "Pausa", "stop": "Parar", "go_start": "Ir para o início", "go_end": "Ir para o fim", "undo-1": "Retroceder -1s", "redo+1": "Avançar +1s",
        "tools": "Ferramentas", "join": "Adicionar vídeo ao final...", "rotate": "Rodar +90°", "unrotate": "Rodar -90°", "extract_audio": "Extrair áudio", "capture": "Capturar fotograma",
        "help": "Ajuda", "shortcuts": "Atalhos de teclado", "about": "Sobre", "status_ready": "Pronto", "selection": "Seleção", "none": "Nenhuma",
        "space_key": "Espaço", "left_arrow": "Seta esquerda", "right_arrow": "Seta direita", 
        "main_area_open": "Abra um ficheiro para começar a editar", "duration": "Duração", "error_play": "Não foi possível iniciar o leitor.", "export_video": "Vídeo exportado", 
        "undo_end": "Desfazer concluído.", "redo_end": "Refazer concluído.", "undo_no": "Não há mais ações para desfazer.", "redo_no": "Não há mais ações para refazer.", "frag_copy": "Fragmento copiado para a área de transferência.", 
        "attention": "Atenção", "no_clip": "A área de transferência está vazia.", "no_paste": "Não foi possível colar.", "mark": "Marque primeiro a parte [A-B].", "error_delete": "Erro ao eliminar.", "save_photo": "Guardar fotograma.",
        "success": "Sucesso", "join_success": "Vídeo adicionado com sucesso ao final do metraje.", "editing": "EDITANDO", "start_video": "Iniciar vídeo", "stop_video": "Parar vídeo.", 
        "no_meta": "Erro ao ler metadados.", "video": "Vídeo", "video_success": "Vídeo guardado com sucesso!", "select_video": "Selecionar vídeo para adicionar ao final",
        "error": "Erro", "join_error": "Não foi possível adicionar o vídeo.", "unifi": "A unificar e concatenar ficheiros...", "wait": "Por favor, aguarde um momento", "plus": "A adicionar vídeo", "save_audio": "Guardar áudio", "finalized": "Finalizado.", "error_extract_audio": "Erro ao extrair áudio:", "error_save_capture": "Erro ao salvar captura de ecrã:", "error_rotate": "Erro de rotação"
    },

    "ro": {
        "title": "JSP Video - Tăiere Video i386",
        "file": "Fișier", "open": "Deschide video...", "save": "Salvează ca...", "export": "Exportă video...", "exit": "Ieșire",
        "edit": "Editare", "undo": "Anulare", "redo": "Refacere", "cut": "Taie fragment", "copy": "Copiază fragment", "paste": "Lipește fragment", "set_start": "Setează început [A]", "set_end": "Setează sfârșit [B]", "clear_sel": "Șterge selecție", "delete": "Șterge fragment",
        "play": "Redare", "pause": "Pauză", "stop": "Stop", "go_start": "Mergi la început", "go_end": "Mergi la sfârșit", "undo-1": "Înapoi -1s", "redo+1": "Înainte +1s",
        "tools": "Unelte", "join": "Adaugă video la final...", "rotate": "Rotește +90°", "unrotate": "Rotește -90°", "extract_audio": "Extrage audio", "capture": "Captură cadru",
        "help": "Ajutor", "shortcuts": "Scurtături tastatură", "about": "Despre", "status_ready": "Gata", "selection": "Selecție", "none": "Niciuna",
        "space_key": "Spațiu", "left_arrow": "Săgeată stânga", "right_arrow": "Săgeată dreapta", 
        "main_area_open": "Deschide un fișier pentru a începe editarea", "duration": "Durată", "error_play": "Playerul nu a putut fi pornit.", "export_video": "Video exportat", 
        "undo_end": "Anulare completă.", "redo_end": "Refacere completă.", "undo_no": "Nu mai există acțiuni de anulat.", "redo_no": "Nu mai există acțiuni de refăcut.", "frag_copy": "Fragment copiat în clipboard.", 
        "attention": "Atenție", "no_clip": "Clipboard-ul este gol.", "no_paste": "Nu s-a putut lipi.", "mark": "Marchează mai întâi partea [A-B].", "error_delete": "Eroare la ștergere.", "save_photo": "Salvează cadru.",
        "success": "Succes", "join_success": "Video adăugat cu succes la final.", "editing": "EDITARE", "start_video": "Pornește video", "stop_video": "Oprește video.", 
        "no_meta": "Eroare la citirea metadatelor.", "video": "Video", "video_success": "Video salvat cu succes!", "select_video": "Selectează video de adăugat la final",
        "error": "Eroare", "join_error": "Video-ul nu a putut fi adăugat.", "unifi": "Unificarea și concatenarea fișierelor...", "wait": "Vă rugăm așteptați", "plus": "Adăugare video", "save_audio": "Salvează audio", "finalized": "Finalizat.", "error_extract_audio": "Eroare la extragerea audio:", "error_save_capture": "Eroare la salvarea capturii:", "error_rotate": "Eroare de rotire"
    },

    "ru": {
        "title": "JSP Video - Видеоредактор i386",
        "file": "Файл", "open": "Открыть видео...", "save": "Сохранить как...", "export": "Экспортировать видео...", "exit": "Выход",
        "edit": "Правка", "undo": "Отменить", "redo": "Вернуть", "cut": "Вырезать фрагмент", "copy": "Копировать фрагмент", "paste": "Вставить фрагмент", "set_start": "Отметить начало [A]", "set_end": "Отметить конец [B]", "clear_sel": "Очистить выбор", "delete": "Удалить фрагмент",
        "play": "Воспроизведение", "pause": "Пауза", "stop": "Стоп", "go_start": "В начало", "go_end": "В конец", "undo-1": "Назад -1с", "redo+1": "Вперед +1с",
        "tools": "Инструменты", "join": "Добавить видео в конец...", "rotate": "Поворот +90°", "unrotate": "Поворот -90°", "extract_audio": "Извлечь аудио", "capture": "Сделать снимок кадра",
        "help": "Справка", "shortcuts": "Горячие клавиши", "about": "О программе", "status_ready": "Готово", "selection": "Выделение", "none": "Нет",
        "space_key": "Пробел", "left_arrow": "Стрелка влево", "right_arrow": "Стрелка вправо", 
        "main_area_open": "Откройте файл, чтобы начать редактирование", "duration": "Длительность", "error_play": "Не удалось запустить плеер.", "export_video": "Видео экспортировано", 
        "undo_end": "Отмена выполнена.", "redo_end": "Возврат выполнен.", "undo_no": "Больше нет действий для отмены.", "redo_no": "Больше нет действий для возврата.", "frag_copy": "Фрагмент скопирован в буфер обмена.", 
        "attention": "Внимание", "no_clip": "Буфер обмена пуст.", "no_paste": "Не удалось вставить.", "mark": "Сначала отметьте часть [A-B].", "error_delete": "Ошибка при удалении.", "save_photo": "Сохранить кадр.",
        "success": "Успешно", "join_success": "Видео успешно добавлено в конец.", "editing": "РЕДАКТИРОВАНИЕ", "start_video": "Запустить видео", "stop_video": "Остановить видео.", 
        "no_meta": "Ошибка чтения метаданных.", "video": "Видео", "video_success": "Видео успешно сохранено!", "select_video": "Выберите видео для добавления в конец",
        "error": "Ошибка", "join_error": "Не удалось добавить видео.", "unifi": "Объединение и конкатенация файлов...", "wait": "Пожалуйста, подождите", "plus": "Добавление видео", "save_audio": "Сохранить аудио", "finalized": "Завершено.", "error_extract_audio": "Ошибка извлечения аудио:", "error_save_capture": "Ошибка сохранения скриншота:", "error_rotate": "Ошибка поворота"
    },

    "tr": {
        "title": "JSP Video - Video Clipper i386",
        "file": "Dosya", "open": "Video Aç...", "save": "Farklı Kaydet...", "export": "Video Dışa Aktar...", "exit": "Çıkış",
        "edit": "Düzenle", "undo": "Geri Al", "redo": "Yinele", "cut": "Parçayı Kes", "copy": "Parçayı Kopyala", "paste": "Parçayı Yapıştır", "set_start": "Başlangıç İşareti [A]", "set_end": "Bitiş İşareti [B]", "clear_sel": "Seçimi Temizle", "delete": "Parçayı Sil",
        "play": "Oynat", "pause": "Duraklat", "stop": "Durdur", "go_start": "Başa Git", "go_end": "Sona Git", "undo-1": "Geri -1s", "redo+1": "İleri +1s",
        "tools": "Araçlar", "join": "Sona video ekle...", "rotate": "Döndür +90°", "unrotate": "Döndür -90°", "extract_audio": "Sesi Çıkart", "capture": "Kareyi Yakala",
        "help": "Yardım", "shortcuts": "Klavye Kısayolları", "about": "Hakkında", "status_ready": "Hazır", "selection": "Seçim", "none": "Yok",
        "space_key": "Boşluk Tuşu", "left_arrow": "Sol ok", "right_arrow": "Sağ ok", 
        "main_area_open": "Düzenlemeye başlamak için bir dosya açın", "duration": "Süre", "error_play": "Oynatıcı başlatılamadı.", "export_video": "Video dışa aktarıldı", 
        "undo_end": "Geri alma tamamlandı.", "redo_end": "Yineleme tamamlandı.", "undo_no": "Geri alınacak başka işlem yok.", "redo_no": "Yinelenecek başka işlem yok.", "frag_copy": "Parça panoya kopyalandı.", 
        "attention": "Dikkat", "no_clip": "Pano boş.", "no_paste": "Yapıştırılamadı.", "mark": "Önce [A-B] kısmını işaretleyin.", "error_delete": "Silme hatası.", "save_photo": "Kareyi kaydet.",
        "success": "Başarılı", "join_success": "Video başarıyla sona eklendi.", "editing": "DÜZENLEME", "start_video": "Videoyu başlat", "stop_video": "Videoyu durdur.", 
        "no_meta": "Meta veri okuma hatası.", "video": "Video", "video_success": "Video başarıyla kaydedildi!", "select_video": "Sona eklenecek videoyu seçin",
        "error": "Hata", "join_error": "Video eklenemedi.", "unifi": "Dosyalar birleştiriliyor...", "wait": "Lütfen biraz bekleyin", "plus": "Video ekleniyor", "save_audio": "Sesi kaydet", "finalized": "Tamamlandı.", "error_extract_audio": "Ses çıkarılırken hata oluştu:", "error_save_capture": "Ekran görüntüsü kaydedilirken hata oluştu:", "error_rotate": "Döndürme hatası"
    },

    "uk": {
        "title": "JSP Video - Відеоредактор i386",
        "file": "Файл", "open": "Відкрити відео...", "save": "Зберегти як...", "export": "Експортувати відео...", "exit": "Вихід",
        "edit": "Редагування", "undo": "Скасувати", "redo": "Повторити", "cut": "Вирізати фрагмент", "copy": "Копіювати фрагмент", "paste": "Вставити фрагмент", "set_start": "Початок [A]", "set_end": "Кінець [B]", "clear_sel": "Очистити вибір", "delete": "Видалити фрагмент",
        "play": "Відтворити", "pause": "Пауза", "stop": "Зупинити", "go_start": "На початок", "go_end": "В кінець", "undo-1": "Назад -1с", "redo+1": "Вперед +1с",
        "tools": "Інструменти", "join": "Додати відео в кінець...", "rotate": "Поворот +90°", "unrotate": "Поворот -90°", "extract_audio": "Витягти аудіо", "capture": "Захопити кадр",
        "help": "Допомога", "shortcuts": "Клавіатурні скорочення", "about": "Про програму", "status_ready": "Готово", "selection": "Вибір", "none": "Немає",
        "space_key": "Пробіл", "left_arrow": "Стрілка вліво", "right_arrow": "Стрілка вправо", 
        "main_area_open": "Відкрийте файл, щоб почати редагування", "duration": "Тривалість", "error_play": "Не вдалося запустити програвач.", "export_video": "Відео експортовано", 
        "undo_end": "Скасування завершено.", "redo_end": "Повторення завершено.", "undo_no": "Більше немає дій для скасування.", "redo_no": "Більше немає дій для повторення.", "frag_copy": "Фрагмент скопійовано у буфер.", 
        "attention": "Увага", "no_clip": "Буфер обміну порожній.", "no_paste": "Не вдалося вставити.", "mark": "Спочатку позначте частину [A-B].", "error_delete": "Помилка при видаленні.", "save_photo": "Зберегти кадр.",
        "success": "Успіх", "join_success": "Відео успішно додано в кінець.", "editing": "РЕДАГУВАННЯ", "start_video": "Запустити відео", "stop_video": "Зупинити відео.", 
        "no_meta": "Помилка читання метаданих.", "video": "Відео", "video_success": "Відео успішно збережено!", "select_video": "Виберіть відео для додавання в кінець",
        "error": "Помилка", "join_error": "Не вдалося додати відео.", "unifi": "Об'єднання та конкатенація файлів...", "wait": "Будь ласка, зачекайте", "plus": "Додавання відео", "save_audio": "Зберегти аудіо", "finalized": "Завершено.", "error_extract_audio": "Помилка вилучення аудіо:", "error_save_capture": "Помилка збереження скріншоту:", "error_rotate": "Помилка повороту"
    },

    "zh": {
        "title": "JSP Video - 视频编辑器 i386",
        "file": "文件", "open": "打开视频...", "save": "另存为...", "export": "导出视频...", "exit": "退出",
        "edit": "编辑", "undo": "撤销", "redo": "重做", "cut": "剪切片段", "copy": "复制片段", "paste": "粘贴片段", "set_start": "标记开始 [A]", "set_end": "标记结束 [B]", "clear_sel": "清除选择", "delete": "删除片段",
        "play": "播放", "pause": "暂停", "stop": "停止", "go_start": "跳到开始", "go_end": "跳到结束", "undo-1": "后退 -1s", "redo+1": "前进 +1s",
        "tools": "工具", "join": "在末尾添加视频...", "rotate": "旋转 +90°", "unrotate": "旋转 -90°", "extract_audio": "提取音频", "capture": "截取画面",
        "help": "帮助", "shortcuts": "键盘快捷键", "about": "关于", "status_ready": "准备就绪", "selection": "选择", "none": "无",
        "space_key": "空格键", "left_arrow": "左箭头", "right_arrow": "右箭头", 
        "main_area_open": "打开一个文件开始编辑", "duration": "时长", "error_play": "无法启动播放器。", "export_video": "视频已导出", 
        "undo_end": "撤销完成。", "redo_end": "重做完成。", "undo_no": "没有更多可撤销的操作。", "redo_no": "没有更多可重做的操作。", "frag_copy": "片段已复制到剪贴板。", 
        "attention": "注意", "no_clip": "剪贴板为空。", "no_paste": "无法粘贴。", "mark": "请先标记 [A-B] 部分。", "error_delete": "删除时出错。", "save_photo": "保存画面。",
        "success": "成功", "join_success": "视频已成功添加至末尾。", "editing": "编辑模式", "start_video": "开始视频", "stop_video": "停止视频。", 
        "no_meta": "读取元数据出错。", "video": "视频", "video_success": "视频保存成功！", "select_video": "选择要添加到末尾的视频",
        "error": "错误", "join_error": "无法添加视频。", "unifi": "正在整合和拼接文件...", "wait": "请稍候", "plus": "正在添加视频", "save_audio": "保存音频", "finalized": "已完成。", "error_extract_audio": "提取音频出错：", "error_save_capture": "保存截图出错：", "error_rotate": "旋转出错"
    }
}

