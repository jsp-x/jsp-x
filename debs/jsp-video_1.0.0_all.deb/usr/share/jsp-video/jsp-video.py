#!/usr/bin/env python3 
# jsp-video.py
import tkinter as tk
from tkinter import filedialog, messagebox 
from tkinter import font
import os
import sys
import shutil
import tempfile
import subprocess
import time
import threading
from core.locale import VIDEO_LANGUAGES
import locale

home = os.path.expanduser("~/")

class VideoHistoryManager:
    def __init__(self):
        self.undo_stack = []
        self.redo_stack = []

    def push_state(self, filepath):
        if not filepath or not os.path.exists(filepath): return
        ext = os.path.splitext(filepath)[1]
        fd, backup_path = tempfile.mkstemp(suffix=ext, prefix="jsp_vid_hist_")
        os.close(fd)
        shutil.copy2(filepath, backup_path)
        self.undo_stack.append(backup_path)
        self.clear_redo()

    def undo(self, current_filepath):
        if not self.undo_stack: return False
        ext = os.path.splitext(current_filepath)[1]
        fd, redo_path = tempfile.mkstemp(suffix=ext, prefix="jsp_vid_hist_")
        os.close(fd)
        shutil.copy2(current_filepath, redo_path)
        self.redo_stack.append(redo_path)
        prev_path = self.undo_stack.pop()
        shutil.copy2(prev_path, current_filepath)
        try: os.remove(prev_path)
        except Exception: pass
        return True

    def redo(self, current_filepath):
        if not self.redo_stack: return False
        ext = os.path.splitext(current_filepath)[1]
        fd, undo_path = tempfile.mkstemp(suffix=ext, prefix="jsp_vid_hist_")
        os.close(fd)
        shutil.copy2(current_filepath, undo_path)
        self.undo_stack.append(undo_path)
        next_path = self.redo_stack.pop()
        shutil.copy2(next_path, current_filepath)
        try: os.remove(next_path)
        except Exception: pass
        return True

    def clear_redo(self):
        while self.redo_stack:
            p = self.redo_stack.pop()
            if os.path.exists(p):
                try: os.remove(p)
                except Exception: pass

    def cleanup(self):
        for p in self.undo_stack + self.redo_stack:
            if os.path.exists(p):
                try: os.remove(p)
                except Exception: pass
        self.undo_stack.clear()
        self.redo_stack.clear()

class VideoTimeline(tk.Canvas):
    def __init__(self, parent, select_callback=None, **kwargs):
        super().__init__(parent, bg="#1a1a1a", height=130, highlightthickness=1, highlightbackground="#333333", **kwargs)
        self.select_callback = select_callback
        self.video_path = None
        self.duration = 0.0
        self.thumbnails = []
        self.temp_dir = tempfile.mkdtemp(prefix="jsp_video_thumbs_")
        self.cursor_x = 15
        self.mark_a_x = None
        self.mark_b_x = None
        self.left_margin = 15
        self.right_margin = 15
        self.bind("<ButtonPress-1>", self.on_click)
        self.bind("<B1-Motion>", self.on_drag)
        self.bind("<Configure>", self.on_resize)

    def set_video(self, video_path, duration):
        self.video_path = video_path
        self.duration = duration
        self.mark_a_x = None
        self.mark_b_x = None
        self.cursor_x = self.left_margin
        self.clear_thumbnails()
        self.draw_timeline()
        threading.Thread(target=self.extract_thumbnails_fast, daemon=True).start()

    def clear_thumbnails(self):
        self.thumbnails.clear()
        if os.path.exists(self.temp_dir):
            try: shutil.rmtree(self.temp_dir)
            except Exception: pass
        self.temp_dir = tempfile.mkdtemp(prefix="jsp_video_thumbs_")

    def extract_thumbnails_fast(self):
        if not self.video_path or self.duration <= 0: return
        num_thumbs = 8
        out_pattern = os.path.join(self.temp_dir, "thumb_%d.png")
        fps_rate = num_thumbs / self.duration if self.duration > 0 else 1
        cmd = [
            'ffmpeg', '-ss', '0', '-i', self.video_path,
            '-vf', f'fps={fps_rate:.4f},scale=120:60',
            '-vframes', str(num_thumbs), '-y', out_pattern
        ]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        for i in range(1, num_thumbs + 1):
            p = os.path.join(self.temp_dir, f"thumb_{i}.png")
            if os.path.exists(p):
                self.after(0, self.load_thumb, p, i - 1)

    def load_thumb(self, path, index):
        try:
            img = tk.PhotoImage(file=path)
            self.thumbnails.append((index, img))
            self.thumbnails.sort(key=lambda x: x[0])
            self.draw_timeline()
        except Exception: pass

    def draw_timeline(self):
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width < 50: return

        usable_width = width - self.left_margin - self.right_margin
        self.create_line(self.left_margin, 25, width - self.right_margin, 25, fill="#888888", width=1)
        if self.duration > 0:
            step_time = self.duration / 10.0
            for i in range(11):
                t_val = i * step_time
                x_pos = self.left_margin + int((i / 10.0) * usable_width)
                self.create_line(x_pos, 20, x_pos, 25, fill="#888888", width=1)
                self.create_text(x_pos, 10, text="{:.1f}s".format(t_val), fill="#888888", font=("Helvetica", 8))

        if self.mark_a_x is not None and self.mark_b_x is not None:
            x1, x2 = min(self.mark_a_x, self.mark_b_x), max(self.mark_a_x, self.mark_b_x)
            self.create_rectangle(x1, 30, x2, height - 10, fill="#003366", outline="")

        if len(self.thumbnails) > 0:
            thumb_w = usable_width / 8
            for idx, img in self.thumbnails:
                x = self.left_margin + (idx * thumb_w)
                self.create_image(x, 35, image=img, anchor=tk.NW)

        if self.mark_a_x is not None:
            self.create_line(self.mark_a_x, 25, self.mark_a_x, height - 5, fill="#00ff00", width=2)
            self.create_text(self.mark_a_x + 5, 45, text="[A", fill="#00ff00", font=("Helvetica", 10, "bold"), anchor=tk.W)

        if self.mark_b_x is not None:
            self.create_line(self.mark_b_x, 25, self.mark_b_x, height - 5, fill="#ff0000", width=2)
            self.create_text(self.mark_b_x - 5, 45, text="B]", fill="#ff0000", font=("Helvetica", 10, "bold"), anchor=tk.E)

        self.create_line(self.cursor_x, 5, self.cursor_x, height - 5, fill="#ffff00", width=2)

    def get_time_at_x(self, x):
        usable_width = self.winfo_width() - self.left_margin - self.right_margin
        if usable_width <= 0 or self.duration <= 0: return 0.0
        relative_x = max(0, min(usable_width, x - self.left_margin))
        return round((relative_x / usable_width) * self.duration, 3)

    def get_x_for_time(self, t):
        usable_width = self.winfo_width() - self.left_margin - self.right_margin
        if self.duration <= 0 or usable_width <= 0: return self.left_margin
        return self.left_margin + int(max(0.0, min(1.0, t / self.duration)) * usable_width)

    def on_click(self, event):
        self.cursor_x = max(self.left_margin, min(self.winfo_width() - self.right_margin, event.x))
        self.draw_timeline()
        if self.select_callback: self.select_callback(self.get_time_at_x(event.x))

    def on_drag(self, event):
        self.cursor_x = max(self.left_margin, min(self.winfo_width() - self.right_margin, event.x))
        self.draw_timeline()
        if self.select_callback: self.select_callback(self.get_time_at_x(self.cursor_x))

    def on_resize(self, event):
        self.recalculate_pixel_marks()
        self.draw_timeline()

    def recalculate_pixel_marks(self):
        if self.duration > 0:
            if self.mark_a_x is not None:
                self.mark_a_x = self.get_x_for_time(self.get_time_at_x(self.mark_a_x))
            if self.mark_b_x is not None:
                self.mark_b_x = self.get_x_for_time(self.get_time_at_x(self.mark_b_x))
            self.cursor_x = self.get_x_for_time(self.get_time_at_x(self.cursor_x))

    def cleanup(self):
        self.clear_thumbnails()
        if os.path.exists(self.temp_dir):
            try: shutil.rmtree(self.temp_dir)
            except Exception: pass

class ShortcutsVideoDialog(tk.Toplevel):
    def __init__(self, parent, lang_dict):
        super().__init__(parent)
        self.title(lang_dict["shortcuts"])
        self.geometry("480x420")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        main_frame = tk.Frame(self, padx=20, pady=15)
        main_frame.pack(fill=tk.BOTH, expand=True)
        tk.Label(main_frame, text=lang_dict["shortcuts"], font=("Helvetica", 12, "bold")).pack(anchor=tk.W, pady=(0, 15))

        grid_frame = tk.Frame(main_frame)
        grid_frame.pack(fill=tk.BOTH, expand=True)

        shortcuts_list = [
            (lang_dict["space_key"], lang_dict["play"]),
            ("Esc / Q", lang_dict["stop"]),
            ("Ctrl + O", lang_dict["open"]),
            ("Ctrl + S", lang_dict["save"]),
            ("Ctrl + Z", lang_dict["undo"]),
            ("Ctrl + Y", lang_dict["redo"]),
            ("Ctrl + X", lang_dict["cut"]),
            ("Ctrl + C", lang_dict["copy"]),
            ("Ctrl + V", lang_dict["paste"]),
            ("Supr", lang_dict["delete"]),
            ("A", lang_dict["set_start"]),
            ("S", lang_dict["set_end"]),
            (lang_dict["left_arrow"], lang_dict["undo-1"]),
            (lang_dict["right_arrow"], lang_dict["redo+1"]),
        ]

        for idx, (tecla, accion) in enumerate(shortcuts_list):
            tk.Label(grid_frame, text=tecla, font=("Helvetica", 11, "bold"), fg="#0055ff", anchor=tk.W).grid(row=idx, column=0, sticky=tk.W, pady=2, padx=(0, 20))
            tk.Label(grid_frame, text=accion, font=("Helvetica", 11), anchor=tk.W).grid(row=idx, column=1, sticky=tk.W, pady=2)

        tk.Button(main_frame, text="OK", command=self.destroy, width=12, font=("Helvetica", 11)).pack(pady=(15, 0))

class JSPVideoApp:
    def __init__(self, root):
        self.root = root
        if sys.platform.startswith('win'):
            self.root.state('zoomed')
        else:
            self.root.attributes('-zoomed', True)

        try:
            self.root.tk.call('set', '::tk::dialog::file::showHiddenBtn', '0')
            self.root.tk.call('set', '::tk::dialog::file::showHiddenVar', '0')
        except: pass

        try:
            icon_path = os.path.join(os.path.dirname(__file__), "resources", "icon2.png")
            if os.path.exists(icon_path):
                img_icon = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, img_icon)
        except Exception: pass

        self.icons = {}
        icon_names = ["open", "save", "export", "cut", "copy", "paste", "delete", "undo", "redo", "exit", "play", "stop", "forward", "backward", "first", "last", "avant", "arrere", "clean", "right", "left", "photo", "video", "audio"]

        for name in icon_names:
            path = os.path.join(os.path.dirname(__file__), "resources", f"{name}.png")
            if os.path.exists(path):
                try: self.icons[name] = tk.PhotoImage(file=path)
                except Exception: self.icons[name] = None
            else: self.icons[name] = None

        try:
            lang_full = locale.getlocale()[0]
            self.lang_code = lang_full.split('_')[0] if (lang_full and '_' in lang_full) else "en"
        except:
            self.lang_code = "en"
            
        self.txt = VIDEO_LANGUAGES.get(self.lang_code, VIDEO_LANGUAGES["en"])

        self.root.title(self.txt["title"])
        self.root.geometry("1100x680")
        self.root.minsize(900, 500)

        self.latencia_inicio = 0.1
        self.history = VideoHistoryManager()
        self.original_filename = None
        self.video_path = None
        self.temp_edit_file = None
        self.duration = 0.0
        self.current_time = 0.0
        self.mark_a = None
        self.mark_b = None
        self.play_process = None
        self.reproduciendo_ahora = False
        self.clock_id = None
        self.current_preview_img = None

        self.setup_menu()
        self.setup_toolbars()
        self.setup_main_area()
        self.setup_statusbar()
        self.bind_keys()

    def setup_menu(self):
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label=f" {self.txt['open']} (Ctrl+O)", command=self.open_video, image=self.icons.get('open', ''), compound='left')
        file_menu.add_command(label=f" {self.txt['save']} (Ctrl+S)", command=self.save_final_video, image=self.icons.get('save', ''), compound='left')
        file_menu.add_command(label=f" {self.txt['export']}", command=self.export_video, image=self.icons.get('export', ''), compound='left')
        file_menu.add_separator()
        file_menu.add_command(label=f" {self.txt['exit']}", command=self.on_exit, image=self.icons.get('exit', ''), compound='left')
        menubar.add_cascade(label=self.txt["file"], menu=file_menu)

        edit_menu = tk.Menu(menubar, tearoff=0)
        edit_menu.add_command(label=f" {self.txt['undo']} (Ctrl+Z)", command=self.undo, image=self.icons.get('undo', ''), compound='left')
        edit_menu.add_command(label=f" {self.txt['redo']} (Ctrl+Y)", command=self.redo, image=self.icons.get('redo', ''), compound='left')
        edit_menu.add_separator()
        edit_menu.add_command(label=f" {self.txt['cut']} (Ctrl+X)", command=self.edit_cut, image=self.icons.get('cut', ''), compound='left')
        edit_menu.add_command(label=f" {self.txt['copy']} (Ctrl+C)", command=self.edit_copy, image=self.icons.get('copy', ''), compound='left')
        edit_menu.add_command(label=f" {self.txt['paste']} (Ctrl+V)", command=self.edit_paste, image=self.icons.get('paste', ''), compound='left')
        edit_menu.add_separator()
        edit_menu.add_command(label=f" {self.txt['set_start']} (A)", command=self.mark_start, image=self.icons.get('first', ''), compound='left')
        edit_menu.add_command(label=f" {self.txt['set_end']} (S)", command=self.mark_end, image=self.icons.get('last', ''), compound='left')
        edit_menu.add_command(label=f" {self.txt['clear_sel']}", command=self.clear_selection, image=self.icons.get('clean', ''), compound='left')
        edit_menu.add_command(label=f" {self.txt['delete']} (Supr)", command=self.delete_segment, image=self.icons.get('delete', ''), compound='left')
        menubar.add_cascade(label=self.txt["edit"], menu=edit_menu)

        play_menu = tk.Menu(menubar, tearoff=0)
        play_menu.add_command(label=f" {self.txt['go_start']}", command=self.go_to_start, image=self.icons.get('backward', ''), compound='left')
        play_menu.add_command(label=f" {self.txt['undo-1']}", command=self.step_backward, image=self.icons.get('arrere', ''), compound='left')
        play_menu.add_command(label=f" {self.txt['play']}", command=self.iniciar_reproduccion, image=self.icons.get('play', ''), compound='left')
        play_menu.add_command(label=f" {self.txt['redo+1']}", command=self.step_forward, image=self.icons.get('avant', ''), compound='left')
        play_menu.add_command(label=f" {self.txt['go_end']}", command=self.go_to_end, image=self.icons.get('forward', ''), compound='left')
        menubar.add_cascade(label=self.txt["play"], menu=play_menu)

        proc_menu = tk.Menu(menubar, tearoff=0)
        proc_menu.add_command(label=f" {self.txt['join']}", command=self.join_videos, image=self.icons.get('video', ''), compound='left')
        proc_menu.add_separator()
        proc_menu.add_command(label=f" {self.txt['rotate']}", command=self.rotate_clockwise, image=self.icons.get('right', ''), compound='left')
        proc_menu.add_command(label=f" {self.txt['unrotate']}", command=self.rotate_counter_clockwise, image=self.icons.get('left', ''), compound='left')
        proc_menu.add_separator()
        proc_menu.add_command(label=f" {self.txt['extract_audio']}", command=self.extract_audio, image=self.icons.get('audio', ''), compound='left')
        proc_menu.add_command(label=f" {self.txt['capture']}", command=self.capture_frame, image=self.icons.get('photo', ''), compound='left')
        menubar.add_cascade(label=self.txt["tools"], menu=proc_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label=self.txt["shortcuts"], command=self.show_shortcuts)
        help_menu.add_command(label=self.txt["about"], command=self.show_about)
        menubar.add_cascade(label=self.txt["help"], menu=help_menu)
        self.root.config(menu=menubar)

    def setup_toolbars(self):
        self.bar_file = tk.Frame(self.root, bd=1, relief=tk.RAISED)
        self.bar_file.pack(side=tk.TOP, fill=tk.X)
        tk.Button(self.bar_file, image=self.icons.get('open'), text=f" {self.txt['open']}", command=self.open_video, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(self.bar_file, image=self.icons.get('save'), text=f" {self.txt['save']}", command=self.save_final_video, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(self.bar_file, image=self.icons.get('export'), text=f" {self.txt['export']}", command=self.export_video, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Frame(self.bar_file, width=15).pack(side=tk.LEFT)
        tk.Button(self.bar_file, image=self.icons.get('video'), text=f" {self.txt['join']}", command=self.join_videos, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(self.bar_file, image=self.icons.get('audio'), text=f" {self.txt['extract_audio']}", command=self.extract_audio, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(self.bar_file, image=self.icons.get('photo'), text=f" {self.txt['capture']}", command=self.capture_frame, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)

        self.bar_edit = tk.Frame(self.root, bd=1, relief=tk.RAISED)
        self.bar_edit.pack(side=tk.TOP, fill=tk.X)
        def add_separator(parent):
            tk.Frame(parent, width=2, bg="#555555").pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=4)
        tk.Button(self.bar_edit, image=self.icons.get('undo'), command=self.undo, relief="flat", compound='left').pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(self.bar_edit, image=self.icons.get('redo'), command=self.redo, relief="flat", compound='left').pack(side=tk.LEFT, padx=2, pady=2)
        add_separator(self.bar_edit)
        tk.Button(self.bar_edit, image=self.icons.get('cut'), command=self.edit_cut, relief="flat", compound='left').pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(self.bar_edit, image=self.icons.get('copy'), command=self.edit_copy, relief="flat", compound='left').pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(self.bar_edit, image=self.icons.get('paste'), command=self.edit_paste, relief="flat", compound='left').pack(side=tk.LEFT, padx=2, pady=2)
        add_separator(self.bar_edit)
        tk.Button(self.bar_edit, image=self.icons.get('first'), text=" [A]", command=self.mark_start, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(self.bar_edit, image=self.icons.get('last'), text=" [B]", command=self.mark_end, relief="flat", compound='right').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(self.bar_edit, image=self.icons.get('clean'), text=f" {self.txt['clear_sel']}", command=self.clear_selection, relief="flat", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(self.bar_edit, image=self.icons.get('delete'), text=f" {self.txt['delete']}", command=self.delete_segment, relief="flat", fg="brown", compound='left').pack(side=tk.LEFT, padx=5, pady=2)
        add_separator(self.bar_edit)
        tk.Button(self.bar_edit, image=self.icons.get('left'), text=f" {self.txt['unrotate']}", command=self.rotate_counter_clockwise, relief="flat", compound='left').pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(self.bar_edit, image=self.icons.get('right'), text=f" {self.txt['rotate']}", command=self.rotate_clockwise, relief="flat", compound='left').pack(side=tk.LEFT, padx=2, pady=2)

    def setup_control_bar(self, parent):
        self.bar_play = tk.Frame(parent, bd=1, relief=tk.SUNKEN)
        self.bar_play.pack(fill=tk.X, pady=10)
        center_frame = tk.Frame(self.bar_play)
        center_frame.pack(anchor=tk.CENTER)
        tk.Button(center_frame, text=f"⏮  {self.txt['go_start']}", command=self.go_to_start, relief="flat").pack(side=tk.LEFT, padx=5, pady=2)
        tk.Button(center_frame, text="◀ -1s", command=self.step_backward, relief="flat").pack(side=tk.LEFT, padx=10, pady=2)
        self.btn_play = tk.Button(center_frame, text=f"▶  {self.txt['play']}", command=self.iniciar_reproduccion, relief="flat", font=("Helvetica", 11, "bold"), fg="#0055ff")
        self.btn_play.pack(side=tk.LEFT, padx=10, pady=4)
        tk.Button(center_frame, text="▶ +1s", command=self.step_forward, relief="flat").pack(side=tk.LEFT, padx=10, pady=2)
        tk.Button(center_frame, text=f"⏭  {self.txt['go_end']}", command=self.go_to_end, relief="flat").pack(side=tk.LEFT, padx=5, pady=2)

    def setup_main_area(self):
        main_frame = tk.Frame(self.root, bg="#111111", padx=15, pady=15)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.info_panel = tk.Frame(main_frame, bg="#000000", bd=1, relief=tk.SOLID)
        self.info_panel.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        self.label_overlay = tk.Label(self.info_panel, text=f"JSP Video Engine\n\n{self.txt['main_area_open']}", bg="#000000", fg="#888888", font=("Helvetica", 14))
        self.label_overlay.pack(fill=tk.BOTH, expand=True)

        self.timeline = VideoTimeline(main_frame, select_callback=self.on_timeline_seek)
        self.timeline.pack(fill=tk.X)
        self.setup_control_bar(main_frame)

    def setup_statusbar(self):
        self.status_frame = tk.Frame(self.root, bd=1, relief=tk.SUNKEN)
        self.status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        self.statusbar = tk.Label(self.status_frame, text=f"{self.txt['status_ready']} | JSP Video Precision Engine", anchor=tk.W)
        self.statusbar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.info_label = tk.Label(self.status_frame, text=f"{self.txt['selection']}: {self.txt['none']}", anchor=tk.E)
        self.info_label.pack(side=tk.RIGHT, padx=10)

    def update_status(self):
        time_str = "Reloj: {:.3f}s / {:.3f}s".format(self.current_time, self.duration)
        self.statusbar.config(text=f"{time_str} | JSP Video Active")
        if self.mark_a is not None and self.mark_b is not None:
            t1, t2 = min(self.mark_a, self.mark_b), max(self.mark_a, self.mark_b)
            self.info_label.config(text=f"A: {t1:.3f}s | B: {t2:.3f}s | {self.txt['duration']}: {t2 - t1:.3f}s")
        elif self.mark_a is not None:
            self.info_label.config(text="A: {:.3f}s | B: --".format(self.mark_a))
        elif self.mark_b is not None:
            self.info_label.config(text="A: -- | B: {:.3f}s".format(self.mark_b))
        else:
            self.info_label.config(text=f"{self.txt['selection']}: {self.txt['none']}")

    def iniciar_reproduccion(self, event=None):
        self.root.focus_set()
        if not self.video_path: return
        if self.reproduciendo_ahora:
            self.forzar_parada_total()
            return
            
        if self.clock_id is not None:
            try: self.root.after_cancel(self.clock_id)
            except Exception: pass
            self.clock_id = None
            
        self.label_overlay.pack_forget()

        win_id = self.info_panel.winfo_id()

        cmd = [
            'mpv',
            f'--wid={win_id}',
            f'--start={self.current_time:.3f}',
            '--no-border',
            '--keep-open=no',
            '--input-default-bindings=no', # <--- Desactiva los atajos propios de mpv
            '--input-vo-keyboard=no',       # <--- Pasa todos los eventos de teclado a Tkinter
            self.video_path
        ]
        
        try:
            self.play_process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.play_start_time = time.perf_counter()
            self.play_start_pos = self.current_time
            self.reproduciendo_ahora = True
            self.btn_play.config(text=f"⏸ {self.txt['pause']}", fg="red")
            self.bucle_reloj_barra()
        except Exception:
            messagebox.showerror(self.txt['error'], self.txt['error_play'])

    def forzar_parada_total(self, event=None):
        self.reproduciendo_ahora = False
        self.btn_play.config(text=f"▶  {self.txt['play']}", fg="#0055ff")
        if self.clock_id is not None:
            try: self.root.after_cancel(self.clock_id)
            except Exception: pass
            self.clock_id = None
        if self.play_process:
            try: self.play_process.terminate()
            except Exception: pass
            self.play_process = None
            
        self.capturar_previsualizacion()
        self.update_status()

    def bucle_reloj_barra(self):
        if not self.reproduciendo_ahora or self.play_process is None or self.play_process.poll() is not None:
            if self.reproduciendo_ahora: self.forzar_parada_total()
            return
        now = time.perf_counter()
        elapsed = max(0, (now - self.play_start_time) - self.latencia_inicio)
        new_time = self.play_start_pos + elapsed
        if new_time < self.duration:
            self.current_time = round(new_time, 3)
            self.timeline.cursor_x = self.timeline.get_x_for_time(self.current_time)
            self.timeline.draw_timeline()
            self.update_status()
            self.clock_id = self.root.after(40, self.bucle_reloj_barra)
        else:
            self.current_time = self.duration
            self.timeline.cursor_x = self.timeline.get_x_for_time(self.duration)
            self.timeline.draw_timeline()
            self.update_status()
            self.clock_id = self.root.after(100, self.bucle_reloj_barra)

    def export_video(self):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        
        home = os.path.expanduser("~/")
        cmd = [
            "zenity", "--file-selection", "--save", "--confirm-overwrite",
            "--filename", os.path.join(home, "exportado.mp4"),
            "--title", self.txt['export'],
            "--file-filter=MP4 | *.mp4", "--file-filter=MKV | *.mkv"
        ]
        
        try:
            save_path = subprocess.check_output(cmd, text=True).strip()
            if not save_path.lower().endswith(('.mp4', '.mkv')):
                save_path += ".mp4"
            
            subprocess.run([
                'ffmpeg', '-i', self.video_path, 
                '-c:v', 'libx264', '-crf', '20', 
                '-c:a', 'aac', '-y', save_path
            ], check=True)
            
            messagebox.showinfo(self.txt['success'], self.txt['export_video'])
        except subprocess.CalledProcessError: return
        except Exception as e: messagebox.showerror(self.txt['error'], str(e))

    def go_to_start(self, event=None):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.current_time = 0.0
        self.timeline.cursor_x = self.timeline.left_margin
        self.timeline.draw_timeline()
        self.capturar_previsualizacion()
        self.update_status()

    def go_to_end(self, event=None):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.current_time = self.duration
        self.timeline.cursor_x = self.timeline.winfo_width() - self.timeline.right_margin
        self.timeline.draw_timeline()
        self.capturar_previsualizacion()
        self.update_status()

    def step_forward(self, event=None):
        if not self.video_path: return
        was_playing = self.reproduciendo_ahora
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.current_time = min(self.duration, self.current_time + 1.0)
        self.timeline.cursor_x = self.timeline.get_x_for_time(self.current_time)
        self.timeline.draw_timeline()
        self.capturar_previsualizacion()
        self.update_status()
        if was_playing: self.iniciar_reproduccion()

    def step_backward(self, event=None):
        if not self.video_path: return
        was_playing = self.reproduciendo_ahora
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.current_time = max(0.0, self.current_time - 1.0)
        self.timeline.cursor_x = self.timeline.get_x_for_time(self.current_time)
        self.timeline.draw_timeline()
        self.capturar_previsualizacion()
        self.update_status()
        if was_playing: self.iniciar_reproduccion()

    def on_timeline_seek(self, t):
        was_playing = self.reproduciendo_ahora
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.current_time = t
        self.capturar_previsualizacion()
        self.update_status()
        if was_playing: self.iniciar_reproduccion()

    def mark_start(self, event=None):
        if not self.video_path: return
        self.mark_a = round(self.current_time, 3)
        self.timeline.mark_a_x = self.timeline.cursor_x
        self.timeline.draw_timeline()
        self.update_status()

    def mark_end(self, event=None):
        if not self.video_path: return
        self.mark_b = round(self.current_time, 3)
        self.timeline.mark_b_x = self.timeline.cursor_x
        self.timeline.draw_timeline()
        self.update_status()

    def clear_selection(self):
        self.mark_a = None
        self.mark_b = None
        self.timeline.mark_a_x = None
        self.timeline.mark_b_x = None
        self.timeline.draw_timeline()
        self.update_status()

    def undo(self):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        if self.history.undo(self.temp_edit_file):
            self.load_video_metadata(self.temp_edit_file)
            self.statusbar.config(text=f"{self.txt['undo_end']}")
        else: messagebox.showinfo(self.txt['attention'], self.txt['undo_no'])

    def redo(self):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        if self.history.redo(self.temp_edit_file):
            self.load_video_metadata(self.temp_edit_file)
            self.statusbar.config(text=f"{self.txt['redo_end']}")
        else: messagebox.showinfo(self.txt['attention'], self.txt['redo_no'])

    def edit_cut(self, event=None):
        if not self.video_path or self.mark_a is None or self.mark_b is None: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.history.push_state(self.temp_edit_file)
        self._save_to_video_clipboard(self.mark_a, self.mark_b)
        self.delete_segment(silent=True)

    def edit_copy(self, event=None):
        if not self.video_path or self.mark_a is None or self.mark_b is None: return
        self._save_to_video_clipboard(self.mark_a, self.mark_b)
        self.statusbar.config(text=f"{self.txt['frag_copy']}")

    def _save_to_video_clipboard(self, start, end):
        t1, t2 = min(start, end), max(start, end)
        ext = os.path.splitext(self.video_path)[1]
        clip_path = os.path.join(tempfile.gettempdir(), f"jsp_vid_clip{ext}")
        cmd = [
            'ffmpeg', '-y',
            '-ss', f"{t1:.3f}", '-to', f"{t2:.3f}",
            '-i', self.video_path,
            '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18',
            '-c:a', 'aac',
            '-avoid_negative_ts', 'make_zero',
            clip_path
        ]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def edit_paste(self, event=None):
        ext = os.path.splitext(self.video_path)[1]
        clip_path = os.path.join(tempfile.gettempdir(), f"jsp_vid_clip{ext}")
        if not os.path.exists(clip_path):
            messagebox.showwarning(self.txt['attention'], self.txt['no_clip'])
            return
            
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.history.push_state(self.temp_edit_file)
        
        temp_dir = tempfile.gettempdir()
        part1 = os.path.join(temp_dir, f"part1_p{ext}")
        part2 = os.path.join(temp_dir, f"part2_p{ext}")
        list_file = os.path.join(temp_dir, "paste_join.txt")
        new_temp = os.path.join(temp_dir, f"jsp_video_paste_res{ext}")
        
        try:
            # Tramo 1: Inicio -> Cursor
            subprocess.run([
                'ffmpeg', '-y', '-ss', '0', '-to', f"{self.current_time:.3f}",
                '-i', self.video_path,
                '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18',
                '-c:a', 'aac', '-avoid_negative_ts', 'make_zero', part1
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Tramo 2: Cursor -> Final
            subprocess.run([
                'ffmpeg', '-y', '-ss', f"{self.current_time:.3f}",
                '-i', self.video_path,
                '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18',
                '-c:a', 'aac', '-avoid_negative_ts', 'make_zero', part2
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            with open(list_file, "w", encoding="utf-8") as f:
                f.write(f"file '{part1}'\nfile '{clip_path}'\nfile '{part2}'\n")
                
            subprocess.run([
                'ffmpeg', '-y', '-f', 'concat', '-safe', '0',
                '-i', list_file, '-c', 'copy', new_temp
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            shutil.move(new_temp, self.temp_edit_file)
            self.load_video_metadata(self.temp_edit_file)
            
        except Exception:
            messagebox.showerror(self.txt['error'], self.txt['no_paste'])
        finally:
            for f in [part1, part2, list_file]:
                if os.path.exists(f):
                    try: os.remove(f)
                    except Exception: pass

    def delete_segment(self, event=None, silent=False):
        if not self.video_path or self.mark_a is None or self.mark_b is None:
            if not silent: messagebox.showwarning(self.txt['attention'], self.txt['mark'])
            return
            
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.history.push_state(self.temp_edit_file)
        
        t1, t2 = min(self.mark_a, self.mark_b), max(self.mark_a, self.mark_b)
        ext = os.path.splitext(self.video_path)[1]
        temp_dir = tempfile.gettempdir()
        
        part1 = os.path.join(temp_dir, f"part1_d{ext}")
        part2 = os.path.join(temp_dir, f"part2_d{ext}")
        list_file = os.path.join(temp_dir, "delete_join.txt")
        new_temp = os.path.join(temp_dir, f"jsp_video_working_nxt{ext}")
        
        try:
            # Parte 1: Inicio -> A
            subprocess.run([
                'ffmpeg', '-y', '-ss', '0', '-to', f"{t1:.3f}",
                '-i', self.video_path,
                '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18',
                '-c:a', 'aac', '-avoid_negative_ts', 'make_zero', part1
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Parte 2: B -> Final
            subprocess.run([
                'ffmpeg', '-y', '-ss', f"{t2:.3f}",
                '-i', self.video_path,
                '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18',
                '-c:a', 'aac', '-avoid_negative_ts', 'make_zero', part2
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            with open(list_file, "w", encoding="utf-8") as f:
                f.write(f"file '{part1}'\nfile '{part2}'\n")
                
            subprocess.run([
                'ffmpeg', '-y', '-f', 'concat', '-safe', '0',
                '-i', list_file, '-c', 'copy', new_temp
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            shutil.move(new_temp, self.temp_edit_file)
            self.load_video_metadata(self.temp_edit_file)
            
        except Exception:
            messagebox.showerror(self.txt['error'], self.txt['error_delete'])
        finally:
            for f in [part1, part2, list_file]:
                if os.path.exists(f):
                    try: os.remove(f)
                    except Exception: pass

    def rotate_clockwise(self): self._apply_rotation_filter("transpose=1")
    def rotate_counter_clockwise(self): self._apply_rotation_filter("transpose=2")

    def _apply_rotation_filter(self, trans_arg):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.history.push_state(self.temp_edit_file)
        ext = os.path.splitext(self.video_path)[1]
        out_temp = os.path.join(tempfile.gettempdir(), f"rotated{ext}")
        cmd = ['ffmpeg', '-y', '-i', self.video_path, '-vf', trans_arg, '-c:a', 'copy', out_temp]
        if subprocess.run(cmd).returncode == 0:
            shutil.move(out_temp, self.temp_edit_file)
            self.load_video_metadata(self.temp_edit_file)
        else: messagebox.showerror(self.txt['error'], self.txt['error_rotate'])

    def capture_frame(self):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        
        home = os.path.expanduser("~/")
        cmd = [
            "zenity", "--file-selection", "--save", "--confirm-overwrite",
            "--title", self.txt['save_photo'],
            "--filename", os.path.join(home, "captura.png"),
            "--file-filter=PNG | *.png", "--file-filter=JPEG | *.jpg *.jpeg", "--file-filter=BMP | *.bmp"
        ]
        
        try:
            save_path = subprocess.check_output(cmd, text=True).strip()
            subprocess.run([
                'ffmpeg', '-y', '-ss', "{:.3f}".format(self.current_time), 
                '-i', self.video_path, '-vframes', '1', 
                '-q:v', '2', save_path
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError: return
        except Exception as e: messagebox.showerror(self.txt['error'], f"{self.txt['error_save_capture']} {str(e)}")

    def capturar_previsualizacion(self):
        """Genera una captura con el tamaño exacto del panel de vídeo para una transición invisible."""
        if not self.video_path: return    
        
        # 1. Obtener el ancho y alto real del panel contenedor en este instante
        self.root.update_idletasks()
        w = self.info_panel.winfo_width()
        h = self.info_panel.winfo_height()
        
        # Valores de respaldo por si el panel aún no se ha dibujado en pantalla
        if w < 50 or h < 50:
            w, h = 640, 480

        preview_path = os.path.join(tempfile.gettempdir(), "jsp_preview_frame.png")
        
        # 2. Pedir a FFmpeg que escale la captura al tamaño exacto de la ventana
        # pad/force_original_aspect_ratio aseguran que encaje como un guante sin deformar la imagen
        cmd = [
            'ffmpeg', '-y',
            '-ss', f"{self.current_time:.3f}",
            '-i', self.video_path,
            '-vf', f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=black",
            '-vframes', '1',
            preview_path
        ]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        if os.path.exists(preview_path):
            try:
                img = tk.PhotoImage(file=preview_path)
                self.current_preview_img = img
                self.label_overlay.config(image=self.current_preview_img, text="", bg="#000000")
                self.label_overlay.pack(fill=tk.BOTH, expand=True)
            except Exception as e:
                print(f"Aviso gráfico en previsualización: {e}")

    def open_video(self, event=None):
        try:
            f = subprocess.check_output([
                "zenity", "--file-selection",
                "--filename", home,
                "--title", self.txt["open"],
                "--file-filter=Vídeos | *.mp4 *.mkv *.avi *.mov",
                "--file-filter=Todos | *"
            ], text=True).strip()
        except subprocess.CalledProcessError: return

        if f:
            self.original_filename = os.path.basename(f)
            self.cleanup_temp_edit_file()
            ext = os.path.splitext(f)[1]
            self.temp_edit_file = os.path.join(tempfile.gettempdir(), f"jsp_video_working{ext}")
            shutil.copy2(f, self.temp_edit_file)
            self.load_video_metadata(self.temp_edit_file)

    def load_video_metadata(self, filepath):
        try:
            result = subprocess.run(
                ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', 
                 '-of', 'default=noprint_wrappers=1:nokey=1', filepath],
                stdout=subprocess.PIPE, text=True, check=True
            )
            self.video_path = filepath
            self.duration = float(result.stdout.strip())
            
            name = self.original_filename if self.original_filename else os.path.basename(filepath)
            self.label_overlay.config(
                text=f"🎬 {self.txt['editing']}: {name}\n\n{self.txt['duration']}: {self.duration:.2f}s\n{self.txt['space_key']}/{self.txt['play']}: {self.txt['start_video']} | Q / Esc {self.txt['stop_video']}",
                fg="#00aaff"
            )
            self.root.update_idletasks()
            self.timeline.set_video(filepath, self.duration)
            self.clear_selection()
        except Exception as e:
            messagebox.showerror(self.txt['error'], f"{self.txt['no_meta']}: {e}")
            return

        try:
            self.capturar_previsualizacion()
        except Exception:
            pass

    def save_final_video(self, event=None):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        
        home = os.path.expanduser("~")
        ext = os.path.splitext(self.video_path)[1]
        cmd = [
            "zenity", "--file-selection", "--save", "--confirm-overwrite",
            "--filename", os.path.join(home, f"video_final{ext}"),
            "--title", "Save Final Video",
            f"--file-filter={self.txt['video']} | *{ext}"
        ]
        
        try:
            save_path = subprocess.check_output(cmd, text=True).strip()
            shutil.copy2(self.video_path, save_path)
            messagebox.showinfo(self.txt['success'], self.txt['video_success'])
        except subprocess.CalledProcessError: return

    def join_videos(self):
        if not self.video_path: return
        
        home = os.path.expanduser("~/")
        cmd = [
            "zenity", "--file-selection", 
            "--title", self.txt['select_video'], 
            "--filename", home,
            f"--file-filter={self.txt['video']} | *.mp4 *.mkv *.avi *.mov *.webm *.flv *.wmv",
            "--file-filter=Todos | *"
        ]
        
        try:
            f_append = subprocess.check_output(cmd, text=True).strip()
        except subprocess.CalledProcessError: return

        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.history.push_state(self.temp_edit_file)
        
        prog_win = tk.Toplevel(self.root)
        prog_win.title(self.txt['plus'])
        prog_win.geometry("380x130")
        prog_win.transient(self.root)
        prog_win.grab_set()
        prog_label = tk.Label(prog_win, text=f"{self.txt['unifi']}\n{self.txt['wait']}", pady=20, font=("Helvetica", 11))
        prog_label.pack()
        self.root.update()

        ext = os.path.splitext(self.video_path)[1]
        temp_dir = tempfile.gettempdir()
        list_file = os.path.join(temp_dir, "append_list.txt")
        new_temp = os.path.join(temp_dir, f"jsp_append_res{ext}")
        
        try:
            # 1. Intentar unión directa ultrarrápida (-c copy)
            with open(list_file, "w", encoding="utf-8") as f:
                f.write(f"file '{self.video_path}'\nfile '{f_append}'\n")
            
            res = subprocess.run(['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', list_file, '-c', 'copy', new_temp], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # 2. Si falla o genera un archivo corrupto/vacío por diferencia de códecs (ej. MKV + MP4)
            if res.returncode != 0 or not os.path.exists(new_temp) or os.path.getsize(new_temp) < 1000:
                prog_label.config(text="Normalizando formatos y códecs incompatibles...\nPor favor, espera un momento.")
                self.root.update()
                
                part1_recoded = os.path.join(temp_dir, f"v_p1_norm{ext}")
                part2_recoded = os.path.join(temp_dir, f"v_p2_norm{ext}")
                
                # Banderas de estandarización universal (H.264 + AAC 44.1kHz Estéreo)
                norm_flags = ['-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '18', '-c:a', 'aac', '-ar', '44100', '-ac', '2']
                
                # Normalizar el vídeo original actual
                subprocess.run(['ffmpeg', '-y', '-i', self.video_path] + norm_flags + [part1_recoded], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                # Normalizar el vídeo nuevo a añadir
                subprocess.run(['ffmpeg', '-y', '-i', f_append] + norm_flags + [part2_recoded], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
                # Reescribir lista con las partes normalizadas
                with open(list_file, "w", encoding="utf-8") as f:
                    f.write(f"file '{part1_recoded}'\nfile '{part2_recoded}'\n")
                    
                # Concatenar los temporales gemelos
                subprocess.run(['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', list_file, '-c', 'copy', new_temp], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
                # Limpiar temporales intermedios
                for f_tmp in [part1_recoded, part2_recoded]:
                    if os.path.exists(f_tmp): 
                        try: os.remove(f_tmp)
                        except Exception: pass

            shutil.move(new_temp, self.temp_edit_file)
            self.load_video_metadata(self.temp_edit_file)
            messagebox.showinfo(self.txt['success'], self.txt['join_success'])
        except Exception as e:
            messagebox.showerror(self.txt['error'], f"{self.txt['join_error']}: {e}")
        finally:
            if os.path.exists(list_file): 
                try: os.remove(list_file)
                except Exception: pass
            prog_win.destroy()

    def extract_audio(self):
        if not self.video_path: return
        if self.reproduciendo_ahora: self.forzar_parada_total()
        
        home = os.path.expanduser("~/")
        cmd = [
            "zenity", "--file-selection", "--save", "--confirm-overwrite",
            "--title", f"{self.txt['save_audio']} WAV",
            "--filename", os.path.join(home, "audio_extraido.wav"),
            "--file-filter=WAV | *.wav"
        ]
        
        try:
            out_path = subprocess.check_output(cmd, text=True).strip()
            if not out_path.lower().endswith(".wav"):
                out_path += ".wav"
                
            subprocess.run([
                'ffmpeg', '-y', '-i', self.video_path, 
                '-vn', '-acodec', 'pcm_s16le', out_path
            ], check=True)
            
            messagebox.showinfo(self.txt['success'], f"{self.txt['save_audio']} {self.txt['finalized']}")
        except subprocess.CalledProcessError: return
        except Exception as e: messagebox.showerror(self.txt['error'], f"{self.txt['error_extract_audio']} {str(e)}")

    def show_shortcuts(self): ShortcutsVideoDialog(self.root, self.txt)
    def show_about(self): messagebox.showinfo("JSP Video", "JSP Video v2.0 Precision Engine\nPython3 + MPV + FFmpeg")

    def bind_keys(self):
        self.root.bind("<Control-o>", self.open_video)
        self.root.bind("<Control-s>", self.save_final_video)
        self.root.bind("<Control-z>", lambda e: self.undo())
        self.root.bind("<Control-y>", lambda e: self.redo())
        self.root.bind("<Control-x>", self.edit_cut)
        self.root.bind("<Control-c>", self.edit_copy)
        self.root.bind("<Control-v>", self.edit_paste)
        self.root.bind("<Delete>", self.delete_segment)
        self.root.bind("<a>", self.mark_start)
        self.root.bind("<s>", self.mark_end)
        self.root.bind("<A>", self.mark_start)
        self.root.bind("<S>", self.mark_end)
        self.root.bind("<space>", self.iniciar_reproduccion)
        self.root.bind("q", self.forzar_parada_total)
        self.root.bind("<Q>", self.forzar_parada_total)
        self.root.bind("<Left>", self.step_backward)
        self.root.bind("<Right>", self.step_forward)
        self.root.bind("<Home>", self.go_to_start)
        self.root.bind("<End>", self.go_to_end)

    def cleanup_temp_edit_file(self):
        if self.temp_edit_file and os.path.exists(self.temp_edit_file):
            try: os.remove(self.temp_edit_file)
            except Exception: pass

    def on_exit(self):
        if self.reproduciendo_ahora: self.forzar_parada_total()
        self.timeline.cleanup()
        self.history.cleanup()
        self.cleanup_temp_edit_file()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    try:
        root.tk.call('set', '::tk::dialog::file::showHiddenBtn', '0')
        root.tk.call('set', '::tk::dialog::file::showHiddenVar', '0')
    except: pass
    font.nametofont("TkDefaultFont").configure(size=12)
    font.nametofont("TkMenuFont").configure(size=12)
    app = JSPVideoApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_exit)
    root.mainloop()
